// Lightweight Base44-compatible client for self-hosted mode
// Backend: server/ (Express + lowdb)
// Usage: set VITE_USE_LOCAL_API=true and VITE_LOCAL_API_BASE_URL=http://localhost:3001

const API_BASE = (import.meta.env.VITE_LOCAL_API_BASE_URL || "http://localhost:3001").replace(/\/+$/, "");

async function apiRequest(method, path, body) {
  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = data?.error || data?.message || `Request failed (${res.status})`;
    throw new Error(msg);
  }
  return data;
}

function makeEntity(entityName) {
  return {
    async filter(where = {}) {
      const params = new URLSearchParams();
      for (const [k, v] of Object.entries(where || {})) {
        if (v === undefined || v === null) continue;
        params.set(k, String(v));
      }
      const qs = params.toString() ? `?${params.toString()}` : "";
      return apiRequest("GET", `/api/entities/${entityName}${qs}`);
    },
    async get(id) {
      return apiRequest("GET", `/api/entities/${entityName}/${id}`);
    },
    async create(data) {
      return apiRequest("POST", `/api/entities/${entityName}`, data);
    },
    async update(id, data) {
      return apiRequest("PATCH", `/api/entities/${entityName}/${id}`, data);
    },
    async delete(id) {
      return apiRequest("DELETE", `/api/entities/${entityName}/${id}`);
    },
    // Some legacy pages use .list; alias to filter({})
    async list(sortField, limit) {
      // Basic implementation - sortField and limit ignored for now
      // TODO: Add sorting support to server if needed
      return apiRequest("GET", `/api/entities/${entityName}`);
    },
  };
}

export const localBase44 = {
  auth: {
    me: () => apiRequest("GET", "/api/auth/me"),
    logout: () => apiRequest("POST", "/api/auth/logout"),
    redirectToLogin: () => {
      // No-op for local mode (replace with real auth later)
      window.location.href = "/";
    },
  },
  entities: {
    WorkbookProgress: makeEntity("WorkbookProgress"),
    CoreValue: makeEntity("CoreValue"),
    SWOTAnalysis: makeEntity("SWOTAnalysis"),
    RootCauseChart: makeEntity("RootCauseChart"),
    TimeAudit: makeEntity("TimeAudit"),
    AICoachConversation: makeEntity("AICoachConversation"),
    Video: makeEntity("Video"),
    Clip: makeEntity("Clip"),
    Topic: makeEntity("Topic"),
    User: makeEntity("users"), // simple mapping
  },
  functions: {
    // FIX: Wrap response in { data: ... } to match Base44 SDK pattern
    invoke: async (name, payload) => {
      const result = await apiRequest("POST", `/api/functions/${name}`, payload);
      return { data: result };
    },
  },
  // Stub for integrations (not implemented in local mode)
  integrations: {
    Core: {
      UploadFile: async ({ file }) => {
        // For local mode, we'd need to implement file upload to server
        // For now, return a placeholder
        console.warn('File upload not implemented in local mode');
        return { file_url: URL.createObjectURL(file) };
      },
      InvokeLLM: async (params) => {
        // LLM not available in local mode - return placeholder
        console.warn('LLM not available in local mode');
        return { 
          suggestions: ['Placeholder suggestion 1', 'Placeholder suggestion 2'],
          text: 'LLM not available in local mode' 
        };
      },
    },
  },
};
