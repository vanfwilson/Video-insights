import { createClient } from '@base44/sdk';
import { appParams } from '@/lib/app-params';
import { localBase44 } from '@/api/localClient';

// Self-host mode: set VITE_USE_LOCAL_API=true and VITE_LOCAL_API_BASE_URL=http://localhost:3001
const USE_LOCAL = String(import.meta.env.VITE_USE_LOCAL_API || '').toLowerCase() === 'true';

const { appId, token, functionsVersion, appBaseUrl } = appParams;

export const base44 = USE_LOCAL
  ? localBase44
  : createClient({
      appId,
      token,
      functionsVersion,
      serverUrl: '',
      requiresAuth: false,
      appBaseUrl,
    });
