import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const STORAGE_KEY = "pickone_strategy_finder_state_v1";

const STRATEGY_LABELS = {
  CORE_VALUE: { label: "Core Value", page: "WorkbookCoreValue" },
  REVISE: { label: "Revise", page: "WorkbookRootCause" },
  EXPAND: { label: "Expand", page: "WorkbookSWOT" },
  DISRUPT: { label: "Disrupt", page: "WorkbookSWOT" },
};

export default function WorkbookStrategyFinder() {
  const { toast } = useToast();

  const [treeId, setTreeId] = useState(() => {
    const saved = safeJson(localStorage.getItem(STORAGE_KEY));
    return saved?.treeId || "pickone-v2";
  });

  const [state, setState] = useState(() => safeJson(localStorage.getItem(STORAGE_KEY))?.state || null);
  const [question, setQuestion] = useState(() => safeJson(localStorage.getItem(STORAGE_KEY))?.question || null);
  const [result, setResult] = useState(() => safeJson(localStorage.getItem(STORAGE_KEY))?.result || null);
  const [treeMeta, setTreeMeta] = useState(() => safeJson(localStorage.getItem(STORAGE_KEY))?.treeMeta || null);
  const [loading, setLoading] = useState(false);

  const canResume = useMemo(() => Boolean(state && (question || result)), [state, question, result]);

  useEffect(() => {
    persist({ treeId, state, question, result, treeMeta });
  }, [treeId, state, question, result, treeMeta]);

  async function start(overwrite = false) {
    setLoading(true);
    try {
      if (overwrite) {
        setState(null);
        setQuestion(null);
        setResult(null);
      }
      const resp = await base44.functions.invoke("strategyDiagnosis", { action: "start", treeId });
      setState(resp.state);
      setQuestion(resp.question);
      setTreeMeta(resp.tree);
      setResult(null);
    } catch (e) {
      toast({ title: "Unable to start", description: e?.message || "Strategy diagnosis failed", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }

  async function answer(answerId) {
    if (!state || !question) return;
    setLoading(true);
    try {
      const resp = await base44.functions.invoke("strategyDiagnosis", {
        action: "answer",
        treeId,
        state,
        questionId: question.id,
        answerId,
      });

      setState(resp.state);

      if (resp.done) {
        setQuestion(null);
        setResult(resp.result);
      } else {
        setQuestion(resp.question);
        setResult(null);
      }
    } catch (e) {
      toast({ title: "Unable to continue", description: e?.message || "Strategy diagnosis failed", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }

  function resetAll() {
    localStorage.removeItem(STORAGE_KEY);
    setState(null);
    setQuestion(null);
    setResult(null);
    setTreeMeta(null);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-semibold">Strategy Finder</h1>
          <p className="text-sm text-muted-foreground">
            Answer a few questions to pick ONE strategy to focus for the next 90 days.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <Select value={treeId} onValueChange={(v) => setTreeId(v)}>
            <SelectTrigger className="w-[260px]">
              <SelectValue placeholder="Choose a tree" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="pickone-v2">Pick One V2 (Fit / Flow / Future / Frontier)</SelectItem>
              <SelectItem value="pickone-map">Pick One Map (direct mirror)</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline" onClick={() => start(true)} disabled={loading}>
            Start
          </Button>
          <Button variant="ghost" onClick={resetAll} disabled={loading}>
            Reset
          </Button>
        </div>
      </div>

      {treeMeta ? (
        <div className="text-xs text-muted-foreground">
          Tree: <span className="font-medium">{treeMeta.name}</span>
        </div>
      ) : null}

      {!canResume ? (
        <Card>
          <CardHeader>
            <CardTitle>Begin</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="text-sm text-muted-foreground">
              Click <span className="font-medium">Start</span> to begin the decision flow.
            </div>
          </CardContent>
        </Card>
      ) : null}

      {question ? (
        <Card>
          <CardHeader>
            <CardTitle>{question.prompt}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {question.tag ? <Badge variant="secondary">{question.tag}</Badge> : null}
            <div className="grid gap-2">
              {question.answers?.map((a) => (
                <Button key={a.id} variant="outline" className="justify-start h-auto py-3 text-left" onClick={() => answer(a.id)} disabled={loading}>
                  {a.label}
                </Button>
              ))}
            </div>
            {state?.history?.length ? (
              <div className="pt-2 text-xs text-muted-foreground">
                Answered: {state.history.length}
              </div>
            ) : null}
          </CardContent>
        </Card>
      ) : null}

      {result ? (
        <Card>
          <CardHeader>
            <CardTitle>Recommendation</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3 flex-wrap">
              <div className="text-xl font-semibold">
                {STRATEGY_LABELS[result.strategy]?.label || result.strategy}
              </div>
              <Badge variant="secondary">
                Confidence: {Math.round((result.confidence || 0) * 100)}%
              </Badge>
            </div>

            <div className="grid gap-2">
              <div className="text-sm font-medium">Scores</div>
              <div className="text-sm text-muted-foreground">
                {result.scores?.map((s) => (
                  <div key={s.strategy} className="flex items-center justify-between">
                    <span>{STRATEGY_LABELS[s.strategy]?.label || s.strategy}</span>
                    <span className="font-mono">{s.score}</span>
                  </div>
                ))}
              </div>
            </div>

            {result.reasons?.length ? (
              <div className="grid gap-2">
                <div className="text-sm font-medium">Top drivers</div>
                <ul className="list-disc pl-5 text-sm text-muted-foreground space-y-1">
                  {result.reasons.map((r, idx) => (
                    <li key={`${r.questionId}-${idx}`}>
                      <span className="font-medium">{r.answer}</span>
                      <span className="text-muted-foreground"> — {r.question}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}

            <div className="flex gap-2 flex-wrap pt-2">
              <Link to={createPageUrl(STRATEGY_LABELS[result.strategy]?.page || "WorkbookDashboard")}>
                <Button>Go to next step</Button>
              </Link>
              <Link to={createPageUrl("WorkbookActionPlan")}>
                <Button variant="outline">Open 90-Day Action Plan</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}

function safeJson(s) {
  try {
    return s ? JSON.parse(s) : null;
  } catch {
    return null;
  }
}

function persist(payload) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
  } catch {}
}
