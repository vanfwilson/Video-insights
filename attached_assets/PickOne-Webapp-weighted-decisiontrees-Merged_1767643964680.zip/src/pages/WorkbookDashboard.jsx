import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { 
    Compass, Target, Grid3X3, GitBranch, Clock, 
    ChevronRight, CheckCircle2, Circle, Sparkles,
    BookOpen, ArrowRight
} from 'lucide-react';

const WORKBOOK_SECTIONS = [
    {
        id: 'core-value',
        title: 'Find Your Core Value',
        description: 'Discover the one value that defines your business',
        icon: Compass,
        page: 'WorkbookCoreValue',
        color: 'bg-blue-500',
        lightColor: 'bg-blue-50',
        borderColor: 'border-blue-200'
    },
    {
        id: 'swot-analysis',
        title: 'SWOT Analysis',
        description: 'Evaluate strengths, weaknesses, opportunities & threats',
        icon: Grid3X3,
        page: 'WorkbookSWOT',
        color: 'bg-green-500',
        lightColor: 'bg-green-50',
        borderColor: 'border-green-200'
    },
    {
        id: 'root-cause',
        title: 'Root Cause Chart',
        description: 'Chart the real problem blocking your growth',
        icon: GitBranch,
        page: 'WorkbookRootCause',
        color: 'bg-purple-500',
        lightColor: 'bg-purple-50',
        borderColor: 'border-purple-200'
    },
    {
        id: 'time-audit',
        title: 'Time Management',
        description: 'Reclaim your time for high-value work',
        icon: Clock,
        page: 'WorkbookTimeAudit',
        color: 'bg-orange-500',
        lightColor: 'bg-orange-50',
        borderColor: 'border-orange-200'
    },
    {
        id: 'action-plan',
        title: '90-Day Action Plan',
        description: 'Turn your work into a concrete roadmap',
        icon: Target,
        page: 'WorkbookActionPlan',
        color: 'bg-slate-800',
        lightColor: 'bg-slate-50',
        borderColor: 'border-slate-200'
    }
];

export default function WorkbookDashboard() {
    const { data: currentUser } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me()
    });

    const { data: workbookProgress, isLoading } = useQuery({
        queryKey: ['workbookProgress'],
        queryFn: async () => {
            try {
                const results = await base44.entities.WorkbookProgress.filter({
                    user_id: currentUser?.id
                });
                return results[0] || null;
            } catch (error) {
                // Entity might not exist yet
                return null;
            }
        },
        enabled: !!currentUser
    });

    const completedSections = workbookProgress?.completed_sections || [];
    const completionPercentage = (completedSections.length / WORKBOOK_SECTIONS.length) * 100;

    const getSectionStatus = (sectionId) => {
        if (completedSections.includes(sectionId)) return 'complete';
        const currentIndex = WORKBOOK_SECTIONS.findIndex(s => s.id === sectionId);
        const previousComplete = currentIndex === 0 || 
            completedSections.includes(WORKBOOK_SECTIONS[currentIndex - 1]?.id);
        return previousComplete ? 'available' : 'locked';
    };

    if (isLoading) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
                <div className="w-8 h-8 border-4 border-slate-200 border-t-blue-600 rounded-full animate-spin" />
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50 p-6">
            <div className="max-w-5xl mx-auto">
                {/* Header */}
                <div className="text-center mb-12 mt-8">
                    <div className="inline-flex items-center gap-2 bg-blue-100 text-blue-700 px-4 py-2 rounded-full text-sm font-medium mb-4">
                        <BookOpen className="w-4 h-4" />
                        Pick One Workbook
                    </div>
                    <h1 className="text-4xl font-bold text-gray-900 mb-4">
                        Your Strategic Planning Journey
                    </h1>
                    <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                        Work through each section to build clarity about your business direction.
                        The AI coach is here to guide you with questions and insights.
                    </p>
                </div>

                {/* Progress Overview */}
                <Card className="mb-8 bg-gradient-to-r from-blue-600 to-indigo-600 text-white border-0">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between mb-4">
                            <div>
                                <h3 className="text-xl font-semibold">Your Progress</h3>
                                <p className="text-blue-100">
                                    {completedSections.length} of {WORKBOOK_SECTIONS.length} sections complete
                                </p>
                            </div>
                            <div className="text-right">
                                <div className="text-4xl font-bold">{Math.round(completionPercentage)}%</div>
                            </div>
                        </div>
                        <Progress value={completionPercentage} className="h-3 bg-blue-400" />
                    </CardContent>
                </Card>

                {/* Welcome Message for New Users */}
                {!workbookProgress && (
                    <Card className="mb-8 border-2 border-dashed border-blue-300 bg-blue-50/50">
                        <CardContent className="pt-6 text-center">
                            <Sparkles className="w-12 h-12 text-blue-500 mx-auto mb-4" />
                            <h3 className="text-xl font-semibold mb-2">Welcome to Your Workbook!</h3>
                            <p className="text-gray-600 mb-4 max-w-lg mx-auto">
                                This is where you'll work through the Pick One methodology step by step.
                                Start with finding your Core Value—it's the foundation for everything else.
                            </p>
                            <Link to={createPageUrl('WorkbookCoreValue')}>
                                <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                                    Start Your Journey
                                    <ArrowRight className="w-4 h-4 ml-2" />
                                </Button>
                            </Link>
                        </CardContent>
                    </Card>
                )}

                {/* Section Cards */}
                <div className="grid gap-6">
                    {WORKBOOK_SECTIONS.map((section, index) => {
                        const status = getSectionStatus(section.id);
                        const Icon = section.icon;
                        
                        return (
                            <Card 
                                key={section.id}
                                className={`
                                    transition-all duration-200 
                                    ${status === 'locked' ? 'opacity-60' : 'hover:shadow-lg hover:-translate-y-1'}
                                    ${section.lightColor} ${section.borderColor} border-2
                                `}
                            >
                                <CardContent className="p-6">
                                    <div className="flex items-center gap-6">
                                        {/* Status Icon */}
                                        <div className={`
                                            w-16 h-16 rounded-2xl flex items-center justify-center
                                            ${status === 'complete' ? 'bg-green-500' : section.color}
                                        `}>
                                            {status === 'complete' ? (
                                                <CheckCircle2 className="w-8 h-8 text-white" />
                                            ) : (
                                                <Icon className="w-8 h-8 text-white" />
                                            )}
                                        </div>

                                        {/* Content */}
                                        <div className="flex-1">
                                            <div className="flex items-center gap-3 mb-1">
                                                <span className="text-sm font-medium text-gray-500">
                                                    Section {index + 1}
                                                </span>
                                                {status === 'complete' && (
                                                    <Badge variant="secondary" className="bg-green-100 text-green-700">
                                                        Complete
                                                    </Badge>
                                                )}
                                                {status === 'locked' && (
                                                    <Badge variant="secondary" className="bg-gray-100 text-gray-500">
                                                        Complete previous section first
                                                    </Badge>
                                                )}
                                            </div>
                                            <h3 className="text-xl font-semibold text-gray-900 mb-1">
                                                {section.title}
                                            </h3>
                                            <p className="text-gray-600">
                                                {section.description}
                                            </p>
                                        </div>

                                        {/* Action */}
                                        <div>
                                            {status !== 'locked' ? (
                                                <Link to={createPageUrl(section.page)}>
                                                    <Button 
                                                        variant={status === 'complete' ? 'outline' : 'default'}
                                                        className="gap-2"
                                                    >
                                                        {status === 'complete' ? 'Review' : 'Continue'}
                                                        <ChevronRight className="w-4 h-4" />
                                                    </Button>
                                                </Link>
                                            ) : (
                                                <Button variant="ghost" disabled className="gap-2">
                                                    <Circle className="w-4 h-4" />
                                                    Locked
                                                </Button>
                                            )}
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        );
                    })}
                </div>

                {/* AI Coach Teaser */}
                <Card className="mt-8 bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-200">
                    <CardContent className="pt-6">
                        <div className="flex items-start gap-4">
                            <div className="w-12 h-12 rounded-full bg-emerald-500 flex items-center justify-center flex-shrink-0">
                                <Sparkles className="w-6 h-6 text-white" />
                            </div>
                            <div>
                                <h3 className="text-lg font-semibold text-gray-900 mb-1">
                                    AI Coach Available
                                </h3>
                                <p className="text-gray-600 mb-3">
                                    Each section includes an AI coach that can ask clarifying questions,
                                    suggest ideas based on your industry, and help you dig deeper into
                                    the exercises.
                                </p>
                                <p className="text-sm text-emerald-700 font-medium">
                                    💡 Powered by the Pick One methodology from Stephen Wright's 30 years of consulting
                                </p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
