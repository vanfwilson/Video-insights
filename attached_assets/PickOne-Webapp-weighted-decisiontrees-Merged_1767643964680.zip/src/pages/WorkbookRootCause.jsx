import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { 
    GitBranch, ArrowLeft, ArrowRight, Save, Sparkles, 
    Loader2, CheckCircle2, MessageCircle, Lightbulb,
    ArrowDown, HelpCircle, Target, AlertCircle
} from 'lucide-react';

export default function WorkbookRootCause() {
    const navigate = useNavigate();
    const queryClient = useQueryClient();
    const [currentStep, setCurrentStep] = useState(1);
    const [aiLoading, setAiLoading] = useState(false);

    // Form state
    const [formData, setFormData] = useState({
        before_triggers: '',
        problem_description: '',
        after_results: '',
        five_whys: [],
        when_where_how: '',
        who_affected: '',
        when_not_issue: '',
        what_driving: '',
        conditions_worse: '',
        how_stop_forever: '',
        who_wins_loses: '',
        what_stopping_us: '',
        symptom: '',
        root_cause: '',
        priority_impact: '',
        problem_statement: ''
    });

    const { data: currentUser } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me()
    });

    // Load existing data
    const { data: existingData, isLoading } = useQuery({
        queryKey: ['rootCauseChart', currentUser?.id],
        queryFn: async () => {
            const results = await base44.entities.RootCauseChart.filter({
                user_id: currentUser?.id
            });
            return results[0] || null;
        },
        enabled: !!currentUser
    });

    useEffect(() => {
        if (existingData) {
            setFormData({
                before_triggers: existingData.before_triggers || '',
                problem_description: existingData.problem_description || '',
                after_results: existingData.after_results || '',
                five_whys: existingData.five_whys || [],
                when_where_how: existingData.when_where_how || '',
                who_affected: existingData.who_affected || '',
                when_not_issue: existingData.when_not_issue || '',
                what_driving: existingData.what_driving || '',
                conditions_worse: existingData.conditions_worse || '',
                how_stop_forever: existingData.how_stop_forever || '',
                who_wins_loses: existingData.who_wins_loses || '',
                what_stopping_us: existingData.what_stopping_us || '',
                symptom: existingData.symptom || '',
                root_cause: existingData.root_cause || '',
                priority_impact: existingData.priority_impact || '',
                problem_statement: existingData.problem_statement || ''
            });
        }
    }, [existingData]);

    const handleFieldChange = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    // Save mutation
    const saveMutation = useMutation({
        mutationFn: async (data) => {
            if (existingData) {
                return base44.entities.RootCauseChart.update(existingData.id, {
                    ...data,
                    updated_at: new Date().toISOString()
                });
            } else {
                return base44.entities.RootCauseChart.create({
                    user_id: currentUser.id,
                    ...data,
                    status: 'draft'
                });
            }
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['rootCauseChart'] });
            toast.success('Progress saved!');
        }
    });

    const handleSave = () => {
        saveMutation.mutate(formData);
    };

    // 5 Whys functionality
    const addWhyAnswer = (answer) => {
        const newWhys = [...formData.five_whys, { question: `Why #${formData.five_whys.length + 1}`, answer }];
        handleFieldChange('five_whys', newWhys);
    };

    const getNextWhyQuestion = async () => {
        setAiLoading(true);
        try {
            const response = await base44.functions.invoke('workbookAICoach', {
                section: 'root-cause',
                action: 'guide_five_whys',
                current_answers: formData
            });

            if (response.data.next_question) {
                toast.info(response.data.next_question);
            }
            if (response.data.reached_root_cause) {
                toast.success('You may have reached the root cause!');
            }
        } catch (error) {
            toast.error('AI guidance unavailable');
        } finally {
            setAiLoading(false);
        }
    };

    const generateProblemStatement = async () => {
        setAiLoading(true);
        try {
            const response = await base44.functions.invoke('workbookAICoach', {
                section: 'root-cause',
                action: 'generate_problem_statement',
                current_answers: formData
            });

            if (response.data.full_statement) {
                setFormData(prev => ({
                    ...prev,
                    symptom: response.data.symptom || prev.symptom,
                    root_cause: response.data.root_cause || prev.root_cause,
                    priority_impact: response.data.priority_impact || prev.priority_impact,
                    problem_statement: response.data.full_statement
                }));
                toast.success('Problem statement generated!');
            }
        } catch (error) {
            toast.error('AI generation failed');
        } finally {
            setAiLoading(false);
        }
    };

    if (isLoading) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-50 flex items-center justify-center">
                <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-indigo-50 p-6">
            <div className="max-w-4xl mx-auto">
                {/* Header */}
                <div className="flex items-center justify-between mb-8">
                    <Button 
                        variant="ghost" 
                        onClick={() => navigate(createPageUrl('WorkbookDashboard'))}
                        className="gap-2"
                    >
                        <ArrowLeft className="w-4 h-4" />
                        Back to Workbook
                    </Button>
                    <Button onClick={handleSave} disabled={saveMutation.isPending} className="gap-2">
                        {saveMutation.isPending ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                            <Save className="w-4 h-4" />
                        )}
                        Save Progress
                    </Button>
                </div>

                {/* Title */}
                <div className="text-center mb-8">
                    <div className="inline-flex items-center gap-2 bg-purple-100 text-purple-700 px-4 py-2 rounded-full text-sm font-medium mb-4">
                        <GitBranch className="w-4 h-4" />
                        Section 3
                    </div>
                    <h1 className="text-3xl font-bold text-gray-900 mb-2">
                        Build Your Root Cause Chart
                    </h1>
                    <p className="text-gray-600">
                        Chart the real problem blocking your growth—not just the symptoms.
                    </p>
                </div>

                {/* Step 1: Problem Flow */}
                <Card className="mb-6">
                    <CardHeader>
                        <CardTitle>Step A: Chart the Problem Flow</CardTitle>
                        <CardDescription>
                            What happens before, during, and after the problem occurs?
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="grid md:grid-cols-3 gap-4">
                            <div className="space-y-2">
                                <Label className="text-blue-600 font-medium">BEFORE (Triggers)</Label>
                                <Textarea
                                    value={formData.before_triggers}
                                    onChange={(e) => handleFieldChange('before_triggers', e.target.value)}
                                    placeholder="What triggers this problem? What happens right before?"
                                    className="min-h-[120px] border-blue-200"
                                />
                            </div>
                            <div className="space-y-2">
                                <Label className="text-red-600 font-medium">THE PROBLEM</Label>
                                <Textarea
                                    value={formData.problem_description}
                                    onChange={(e) => handleFieldChange('problem_description', e.target.value)}
                                    placeholder="Describe the problem clearly..."
                                    className="min-h-[120px] border-red-200"
                                />
                            </div>
                            <div className="space-y-2">
                                <Label className="text-green-600 font-medium">AFTER (Results)</Label>
                                <Textarea
                                    value={formData.after_results}
                                    onChange={(e) => handleFieldChange('after_results', e.target.value)}
                                    placeholder="What happens as a result? What's the impact?"
                                    className="min-h-[120px] border-green-200"
                                />
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {/* Step 2: Five Whys */}
                <Card className="mb-6 border-2 border-purple-200 bg-purple-50/50">
                    <CardHeader>
                        <div className="flex items-center justify-between">
                            <div>
                                <CardTitle className="flex items-center gap-2">
                                    <HelpCircle className="w-5 h-5 text-purple-600" />
                                    Step B: The 5 Whys
                                </CardTitle>
                                <CardDescription>
                                    Keep asking "Why?" to dig past symptoms to the root cause.
                                </CardDescription>
                            </div>
                            <Button 
                                variant="outline" 
                                onClick={getNextWhyQuestion}
                                disabled={aiLoading}
                                className="gap-2"
                            >
                                {aiLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                                AI Guide
                            </Button>
                        </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {/* Existing Whys */}
                        {formData.five_whys.map((why, idx) => (
                            <div key={idx} className="bg-white rounded-lg p-4 border">
                                <div className="flex items-center gap-2 mb-2">
                                    <Badge variant="outline" className="bg-purple-100">Why #{idx + 1}</Badge>
                                </div>
                                <p className="text-gray-800">{why.answer}</p>
                            </div>
                        ))}

                        {/* Add new Why */}
                        {formData.five_whys.length < 5 && (
                            <div className="space-y-2">
                                <Label>Why #{formData.five_whys.length + 1}: Why does this happen?</Label>
                                <div className="flex gap-2">
                                    <Input
                                        id="newWhyInput"
                                        placeholder="Because..."
                                        onKeyPress={(e) => {
                                            if (e.key === 'Enter' && e.target.value.trim()) {
                                                addWhyAnswer(e.target.value.trim());
                                                e.target.value = '';
                                            }
                                        }}
                                    />
                                    <Button 
                                        onClick={() => {
                                            const input = document.getElementById('newWhyInput');
                                            if (input.value.trim()) {
                                                addWhyAnswer(input.value.trim());
                                                input.value = '';
                                            }
                                        }}
                                    >
                                        Add
                                    </Button>
                                </div>
                            </div>
                        )}

                        {formData.five_whys.length >= 5 && (
                            <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center gap-3">
                                <CheckCircle2 className="w-5 h-5 text-green-600" />
                                <span className="text-green-700 font-medium">
                                    You've completed the 5 Whys! Review your answers to identify the root cause.
                                </span>
                            </div>
                        )}
                    </CardContent>
                </Card>

                {/* Step 3: Dig Deep Questions */}
                <Card className="mb-6">
                    <CardHeader>
                        <CardTitle>Step C: Dig Deep Questions</CardTitle>
                        <CardDescription>
                            Answer these to fully understand the problem before writing your statement.
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label>When, where, and how does this happen?</Label>
                            <Textarea
                                value={formData.when_where_how}
                                onChange={(e) => handleFieldChange('when_where_how', e.target.value)}
                                placeholder="Be specific about timing and circumstances..."
                                className="min-h-[80px]"
                            />
                        </div>
                        <div className="space-y-2">
                            <Label>Who is affected (directly and indirectly)?</Label>
                            <Textarea
                                value={formData.who_affected}
                                onChange={(e) => handleFieldChange('who_affected', e.target.value)}
                                placeholder="Customers, staff, partners..."
                                className="min-h-[80px]"
                            />
                        </div>
                        <div className="space-y-2">
                            <Label>When does it NOT cause an issue?</Label>
                            <Textarea
                                value={formData.when_not_issue}
                                onChange={(e) => handleFieldChange('when_not_issue', e.target.value)}
                                placeholder="What's different when things go well?"
                                className="min-h-[80px]"
                            />
                        </div>
                        <div className="space-y-2">
                            <Label>What do you believe is driving this?</Label>
                            <Textarea
                                value={formData.what_driving}
                                onChange={(e) => handleFieldChange('what_driving', e.target.value)}
                                placeholder="Your best guess at the cause..."
                                className="min-h-[80px]"
                            />
                        </div>
                        <div className="space-y-2">
                            <Label>What conditions make it worse?</Label>
                            <Textarea
                                value={formData.conditions_worse}
                                onChange={(e) => handleFieldChange('conditions_worse', e.target.value)}
                                placeholder="Busy seasons, certain customers, etc..."
                                className="min-h-[80px]"
                            />
                        </div>
                        <div className="space-y-2">
                            <Label>How could you stop this FOREVER?</Label>
                            <Textarea
                                value={formData.how_stop_forever}
                                onChange={(e) => handleFieldChange('how_stop_forever', e.target.value)}
                                placeholder="If you had unlimited resources..."
                                className="min-h-[80px]"
                            />
                        </div>
                    </CardContent>
                </Card>

                {/* Step 4: Problem Statement */}
                <Card className="mb-6 border-2 border-indigo-200 bg-indigo-50/50">
                    <CardHeader>
                        <div className="flex items-center justify-between">
                            <div>
                                <CardTitle className="flex items-center gap-2">
                                    <Target className="w-5 h-5 text-indigo-600" />
                                    Step D: Root Cause Problem Statement
                                </CardTitle>
                                <CardDescription>
                                    Write a clear statement that captures the symptom, root cause, and impact.
                                </CardDescription>
                            </div>
                            <Button 
                                onClick={generateProblemStatement}
                                disabled={aiLoading}
                                className="gap-2"
                            >
                                {aiLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                                AI Generate
                            </Button>
                        </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="grid md:grid-cols-3 gap-4">
                            <div className="space-y-2">
                                <Label className="text-red-600">1. The Symptom</Label>
                                <Textarea
                                    value={formData.symptom}
                                    onChange={(e) => handleFieldChange('symptom', e.target.value)}
                                    placeholder="What pain are we feeling?"
                                    className="min-h-[80px]"
                                />
                            </div>
                            <div className="space-y-2">
                                <Label className="text-purple-600">2. The Root Cause</Label>
                                <Textarea
                                    value={formData.root_cause}
                                    onChange={(e) => handleFieldChange('root_cause', e.target.value)}
                                    placeholder="What's driving it beneath the surface?"
                                    className="min-h-[80px]"
                                />
                            </div>
                            <div className="space-y-2">
                                <Label className="text-blue-600">3. Priority Impact</Label>
                                <Textarea
                                    value={formData.priority_impact}
                                    onChange={(e) => handleFieldChange('priority_impact', e.target.value)}
                                    placeholder="Which business areas are most affected?"
                                    className="min-h-[80px]"
                                />
                            </div>
                        </div>

                        <div className="pt-4 border-t">
                            <Label className="text-lg font-semibold mb-2 block">
                                Your Root Cause Problem Statement
                            </Label>
                            <Textarea
                                value={formData.problem_statement}
                                onChange={(e) => handleFieldChange('problem_statement', e.target.value)}
                                placeholder="The problem (which is...) is caused by... which results in... affecting..."
                                className="min-h-[120px] text-lg"
                            />
                        </div>
                    </CardContent>
                </Card>

                {/* Navigation */}
                <div className="flex items-center justify-between mt-8 pt-6 border-t">
                    <Button
                        variant="outline"
                        onClick={() => navigate(createPageUrl('WorkbookSWOT'))}
                        className="gap-2"
                    >
                        <ArrowLeft className="w-4 h-4" />
                        Back to SWOT
                    </Button>
                    
                    <Button
                        onClick={() => {
                            handleSave();
                            navigate(createPageUrl('WorkbookTimeAudit'));
                        }}
                        className="gap-2 bg-purple-600 hover:bg-purple-700"
                    >
                        Continue to Time Audit
                        <ArrowRight className="w-4 h-4" />
                    </Button>
                </div>
            </div>
        </div>
    );
}
