import React, { useMemo, useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { ArrowLeft, Save, Calendar, CheckCircle2, Target, Loader2 } from 'lucide-react';

function safeJsonParse(s, fallback) {
  try { return JSON.parse(s); } catch { return fallback; }
}

function buildSummary({ coreValue, swot, rootCause, timeAudit }) {
  const cv = coreValue?.core_value_final || coreValue?.core_value_statement || coreValue?.draft_core_value || '';
  const issue = swot?.top_issues?.[0] || swot?.selected_issue || '';
  const opp = swot?.top_opportunities?.[0] || swot?.selected_opportunity || '';
  const area = swot?.focus_area_label || swot?.focus_area || '';
  const problem = rootCause?.problem_statement || '';
  const hours = timeAudit?.analysis?.hours_reclaimable || timeAudit?.hours_reclaimable || '';

  const parts = [
    cv ? `Core Value: ${cv}` : null,
    issue ? `Primary Issue: ${issue}` : null,
    opp ? `Primary Opportunity: ${opp}` : null,
    area ? `Focus Area: ${area}` : null,
    problem ? `Constraint: ${problem}` : null,
    hours ? `Hours reclaimable/week: ${hours}` : null,
  ].filter(Boolean);

  return parts.join('\n');
}

function generate90DayPlan(strategy, { swot }) {
  const s = (strategy || '').toLowerCase();
  const issue = swot?.top_issues?.[0] || 'your #1 issue';
  const opp = swot?.top_opportunities?.[0] || 'your #1 opportunity';
  const area = swot?.focus_area_label || swot?.focus_area || 'your focus area';

  if (s.includes('revise') || s === 'r') {
    return {
      strategyLabel: 'Revise (R)',
      milestones: [
        { title: `Stabilize: stop the cycle around ${issue}`, weeks: '1-2' },
        { title: `Fix the bottleneck in ${area} with one new system`, weeks: '3-6' },
        { title: `Lock the gains: SOPs + scorecards to prevent relapse`, weeks: '7-12' },
      ],
      tasks: [
        { title: 'Write the one-sentence problem statement (observable constraint)', owner: 'Owner', dueWeek: 1 },
        { title: `Identify the single bottleneck in ${area}`, owner: 'Owner', dueWeek: 1 },
        { title: 'Create a 2-page SOP for the bottleneck process', owner: 'Ops', dueWeek: 3 },
        { title: 'Add a weekly scorecard (3-5 numbers) for the process', owner: 'Owner', dueWeek: 4 },
        { title: 'Run a 14-day test and review results', owner: 'Owner', dueWeek: 6 },
        { title: 'Document handoff + training checklist', owner: 'Ops', dueWeek: 8 },
      ],
      metrics: [
        { name: 'Cycle time (days)', baseline: '', target: '↓ 20%', cadence: 'weekly' },
        { name: 'Rework / callbacks', baseline: '', target: '↓ 30%', cadence: 'weekly' },
        { name: 'On-time completion %', baseline: '', target: '≥ 95%', cadence: 'weekly' },
      ],
    };
  }

  if (s.includes('expand') || s === 'e') {
    return {
      strategyLabel: 'Expand (E)',
      milestones: [
        { title: `Capacity: remove the ceiling in ${area}`, weeks: '1-3' },
        { title: `Scale: replicate what works to capture ${opp}`, weeks: '4-8' },
        { title: `Systemize: hire/train to sustain growth`, weeks: '9-12' },
      ],
      tasks: [
        { title: 'Choose ONE growth lever (pricing, throughput, upsell, referrals)', owner: 'Owner', dueWeek: 1 },
        { title: 'Define your "best customer" and one offer for them', owner: 'Owner', dueWeek: 2 },
        { title: 'Build a simple pipeline board (lead → won) with stages', owner: 'Sales', dueWeek: 3 },
        { title: 'Add a weekly production plan (capacity vs demand)', owner: 'Ops', dueWeek: 4 },
        { title: 'Create a hiring/training checklist for the next role', owner: 'Owner', dueWeek: 8 },
      ],
      metrics: [
        { name: 'Qualified leads/week', baseline: '', target: '↑ 25%', cadence: 'weekly' },
        { name: 'Close rate %', baseline: '', target: '↑ 10%', cadence: 'weekly' },
        { name: 'Revenue per labor hour', baseline: '', target: '↑ 15%', cadence: 'weekly' },
      ],
    };
  }

  // Default: Disrupt
  return {
    strategyLabel: 'Disrupt (D)',
    milestones: [
      { title: 'Reset: stop profit leaks + get pricing clarity', weeks: '1-2' },
      { title: `Differentiate: build a new offer around ${opp}`, weeks: '3-7' },
      { title: 'Launch: validate with paid customers and iterate', weeks: '8-12' },
    ],
    tasks: [
      { title: 'Compute true costs (labor, materials, overhead) for top services', owner: 'Owner', dueWeek: 1 },
      { title: 'Raise/reshape pricing on one flagship offer', owner: 'Owner', dueWeek: 2 },
      { title: 'Draft a "why choose us" promise (one sentence) + proof', owner: 'Owner', dueWeek: 3 },
      { title: 'Run 10 customer interviews to validate needs', owner: 'Owner', dueWeek: 4 },
      { title: 'Launch a 2-week paid pilot with a clear guarantee', owner: 'Sales', dueWeek: 8 },
    ],
    metrics: [
      { name: 'Gross margin %', baseline: '', target: '↑ 10 pts', cadence: 'weekly' },
      { name: 'Average job value', baseline: '', target: '↑ 15%', cadence: 'weekly' },
      { name: 'Profit/week', baseline: '', target: 'positive & growing', cadence: 'weekly' },
    ],
  };
}

export default function WorkbookActionPlan() {
  const navigate = useNavigate();
  
  const { data: currentUser, isLoading: userLoading } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: progress } = useQuery({
    queryKey: ['workbookProgress', currentUser?.id],
    queryFn: async () => {
      if (!currentUser?.id) return null;
      const res = await base44.entities.WorkbookProgress.filter({ user_id: currentUser.id });
      return res?.[0] || null;
    },
    enabled: !!currentUser?.id,
  });

  const { data: coreValue, isLoading: cvLoading } = useQuery({
    queryKey: ['coreValue', currentUser?.id],
    queryFn: async () => {
      if (!currentUser?.id) return null;
      const res = await base44.entities.CoreValue.filter({ user_id: currentUser.id });
      return res?.[0] || null;
    },
    enabled: !!currentUser?.id,
  });

  const { data: swot, isLoading: swotLoading } = useQuery({
    queryKey: ['swot', currentUser?.id],
    queryFn: async () => {
      if (!currentUser?.id) return null;
      const res = await base44.entities.SWOTAnalysis.filter({ user_id: currentUser.id });
      return res?.[0] || null;
    },
    enabled: !!currentUser?.id,
  });

  const { data: rootCause, isLoading: rcLoading } = useQuery({
    queryKey: ['rootCause', currentUser?.id],
    queryFn: async () => {
      if (!currentUser?.id) return null;
      const res = await base44.entities.RootCauseChart.filter({ user_id: currentUser.id });
      return res?.[0] || null;
    },
    enabled: !!currentUser?.id,
  });

  const { data: timeAudit, isLoading: taLoading } = useQuery({
    queryKey: ['timeAudit', currentUser?.id],
    queryFn: async () => {
      if (!currentUser?.id) return null;
      const res = await base44.entities.TimeAudit.filter({ user_id: currentUser.id });
      return res?.[0] || null;
    },
    enabled: !!currentUser?.id,
  });

  // Storage key for localStorage
  const storageKey = useMemo(() => 
    currentUser?.id ? `pickone_actionplan_${currentUser.id}` : null, 
    [currentUser?.id]
  );

  // State for the plan
  const [plan, setPlan] = useState(null);
  const [hasInitialized, setHasInitialized] = useState(false);

  // FIX: Use useEffect to properly initialize plan after data loads
  useEffect(() => {
    // Don't reinitialize if already done
    if (hasInitialized) return;
    
    // Need storageKey (requires currentUser)
    if (!storageKey) return;

    // Try loading from localStorage first
    const saved = safeJsonParse(localStorage.getItem(storageKey), null);
    if (saved) {
      setPlan(saved);
      setHasInitialized(true);
      return;
    }

    // Need at least some workbook data to generate a plan
    const hasData = swot || coreValue || rootCause || timeAudit;
    if (!hasData) return;

    // Generate new plan based on data
    const strategy = swot?.selected_strategy || progress?.recommended_strategy || progress?.selected_strategy || 'Disrupt';
    const generated = generate90DayPlan(strategy, { swot });

    const newPlan = {
      title: `90-Day Action Plan (${generated.strategyLabel})`,
      strategy: generated.strategyLabel,
      summary: buildSummary({ coreValue, swot, rootCause, timeAudit }),
      milestones: generated.milestones.map((m, i) => ({ id: String(i + 1), status: 'planned', ...m })),
      tasks: generated.tasks.map((t, i) => ({ id: String(i + 1), status: 'planned', ...t })),
      metrics: generated.metrics.map((m, i) => ({ id: String(i + 1), ...m })),
      notes: '',
      created_at: new Date().toISOString(),
    };

    setPlan(newPlan);
    setHasInitialized(true);
  }, [storageKey, swot, progress, coreValue, rootCause, timeAudit, hasInitialized]);

  const handleSave = () => {
    if (!storageKey || !plan) return;
    localStorage.setItem(storageKey, JSON.stringify(plan, null, 2));
    toast.success('Saved (local browser storage)');
  };

  const updateTask = (id, patch) => {
    setPlan((prev) => ({
      ...prev,
      tasks: prev.tasks.map((t) => (t.id === id ? { ...t, ...patch } : t)),
    }));
  };

  const updateMilestone = (id, patch) => {
    setPlan((prev) => ({
      ...prev,
      milestones: prev.milestones.map((m) => (m.id === id ? { ...m, ...patch } : m)),
    }));
  };

  const updateMetric = (id, patch) => {
    setPlan((prev) => ({
      ...prev,
      metrics: prev.metrics.map((m) => (m.id === id ? { ...m, ...patch } : m)),
    }));
  };

  const markDone = (type, id) => {
    if (type === 'task') updateTask(id, { status: 'done' });
    if (type === 'milestone') updateMilestone(id, { status: 'done' });
  };

  // Loading state
  const isLoading = userLoading || cvLoading || swotLoading || rcLoading || taLoading;
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-slate-600" />
      </div>
    );
  }

  // No data yet state
  if (!plan) {
    const hasAnyData = swot || coreValue || rootCause || timeAudit;
    
    return (
      <div className="p-6">
        <Card>
          <CardHeader>
            <CardTitle>90-Day Action Plan</CardTitle>
            <CardDescription>
              {hasAnyData 
                ? "Generating your action plan..."
                : "Complete at least one workbook section to generate a plan."
              }
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => navigate(createPageUrl('WorkbookDashboard'))}>
              <ArrowLeft className="w-4 h-4 mr-2" /> Back to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Target className="w-6 h-6" /> {plan.title}
          </h1>
          <div className="mt-1 flex flex-wrap items-center gap-2">
            <Badge variant="secondary">{plan.strategy}</Badge>
            <Badge variant="outline" className="flex items-center gap-1"><Calendar className="w-3 h-3" /> 90 days</Badge>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => navigate(createPageUrl('WorkbookDashboard'))}>
            <ArrowLeft className="w-4 h-4 mr-2" /> Dashboard
          </Button>
          <Button onClick={handleSave}>
            <Save className="w-4 h-4 mr-2" /> Save
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Summary (auto-built)</CardTitle>
          <CardDescription>Edit as needed — this becomes the top of your report.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <Textarea value={plan.summary} onChange={(e) => setPlan({ ...plan, summary: e.target.value })} rows={6} />
          <div>
            <Label>Notes</Label>
            <Textarea value={plan.notes} onChange={(e) => setPlan({ ...plan, notes: e.target.value })} rows={4} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Milestones</CardTitle>
          <CardDescription>3 checkpoints that define success.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {plan.milestones.map((m) => (
            <div key={m.id} className="border rounded-lg p-3 flex items-start justify-between gap-3">
              <div className="flex-1">
                <Input
                  value={m.title}
                  onChange={(e) => updateMilestone(m.id, { title: e.target.value })}
                />
                <div className="mt-2 flex gap-2">
                  <Label className="text-xs">Weeks</Label>
                  <Input
                    className="max-w-[120px]"
                    value={m.weeks}
                    onChange={(e) => updateMilestone(m.id, { weeks: e.target.value })}
                  />
                  <Badge variant={m.status === 'done' ? 'default' : 'secondary'}>
                    {m.status}
                  </Badge>
                </div>
              </div>
              <Button variant="outline" onClick={() => markDone('milestone', m.id)}>
                <CheckCircle2 className="w-4 h-4 mr-2" /> Done
              </Button>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Tasks</CardTitle>
          <CardDescription>Concrete steps with owners and due weeks.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {plan.tasks.map((t) => (
            <div key={t.id} className="border rounded-lg p-3 grid grid-cols-1 md:grid-cols-12 gap-2 items-center">
              <div className="md:col-span-6">
                <Input value={t.title} onChange={(e) => updateTask(t.id, { title: e.target.value })} />
              </div>
              <div className="md:col-span-2">
                <Input value={t.owner} onChange={(e) => updateTask(t.id, { owner: e.target.value })} placeholder="Owner" />
              </div>
              <div className="md:col-span-2">
                <Input
                  value={t.dueWeek}
                  onChange={(e) => updateTask(t.id, { dueWeek: e.target.value })}
                  placeholder="Due week"
                />
              </div>
              <div className="md:col-span-2 flex items-center gap-2 justify-end">
                <Badge variant={t.status === 'done' ? 'default' : 'secondary'}>{t.status}</Badge>
                <Button size="sm" variant="outline" onClick={() => markDone('task', t.id)}>
                  <CheckCircle2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Metrics</CardTitle>
          <CardDescription>3-5 numbers you review every week.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {plan.metrics.map((m) => (
            <div key={m.id} className="border rounded-lg p-3 grid grid-cols-1 md:grid-cols-12 gap-2 items-center">
              <div className="md:col-span-4">
                <Input value={m.name} onChange={(e) => updateMetric(m.id, { name: e.target.value })} />
              </div>
              <div className="md:col-span-3">
                <Input value={m.baseline} onChange={(e) => updateMetric(m.id, { baseline: e.target.value })} placeholder="Baseline" />
              </div>
              <div className="md:col-span-3">
                <Input value={m.target} onChange={(e) => updateMetric(m.id, { target: e.target.value })} placeholder="Target" />
              </div>
              <div className="md:col-span-2">
                <Input value={m.cadence} onChange={(e) => updateMetric(m.id, { cadence: e.target.value })} placeholder="Cadence" />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={handleSave}>
          <Save className="w-4 h-4 mr-2" /> Save
        </Button>
      </div>
    </div>
  );
}
