import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import { 
    Clock, ArrowLeft, Save, Sparkles, 
    Loader2, CheckCircle2, Plus, Trash2,
    DollarSign, TrendingUp, Users, AlertCircle
} from 'lucide-react';

export default function WorkbookTimeAudit() {
    const navigate = useNavigate();
    const queryClient = useQueryClient();
    const [aiLoading, setAiLoading] = useState(false);
    const [aiAnalysis, setAiAnalysis] = useState(null);

    // Form state
    const [formData, setFormData] = useState({
        owner_rate: 150,
        tasks: [],
        hours_to_reclaim: 0,
        what_to_do_with_time: '',
        time_management_rating: 3,
        biggest_time_wasters: []
    });

    const [newTask, setNewTask] = useState({
        task: '',
        hours: '',
        dollar_value: '',
        rating: 'medium',
        delegate_to: ''
    });

    const { data: currentUser } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me()
    });

    // Load existing data
    const { data: existingData, isLoading } = useQuery({
        queryKey: ['timeAudit', currentUser?.id],
        queryFn: async () => {
            const results = await base44.entities.TimeAudit.filter({
                user_id: currentUser?.id
            });
            return results[0] || null;
        },
        enabled: !!currentUser
    });

    useEffect(() => {
        if (existingData) {
            setFormData({
                owner_rate: existingData.owner_rate || 150,
                tasks: existingData.tasks || [],
                hours_to_reclaim: existingData.hours_to_reclaim || 0,
                what_to_do_with_time: existingData.what_to_do_with_time || '',
                time_management_rating: existingData.time_management_rating || 3,
                biggest_time_wasters: existingData.biggest_time_wasters || []
            });
        }
    }, [existingData]);

    // Save mutation
    const saveMutation = useMutation({
        mutationFn: async (data) => {
            // Calculate totals
            const tasks = data.tasks || [];
            const totalHours = tasks.reduce((sum, t) => sum + (parseFloat(t.hours) || 0), 0);
            const highValueHours = tasks.filter(t => t.rating === 'high').reduce((sum, t) => sum + (parseFloat(t.hours) || 0), 0);
            const mediumValueHours = tasks.filter(t => t.rating === 'medium').reduce((sum, t) => sum + (parseFloat(t.hours) || 0), 0);
            const lowValueHours = tasks.filter(t => t.rating === 'low').reduce((sum, t) => sum + (parseFloat(t.hours) || 0), 0);

            const payload = {
                user_id: currentUser.id,
                ...data,
                total_hours_logged: totalHours,
                high_value_hours: highValueHours,
                medium_value_hours: mediumValueHours,
                low_value_hours: lowValueHours,
                status: 'draft',
                updated_at: new Date().toISOString()
            };

            if (existingData) {
                return base44.entities.TimeAudit.update(existingData.id, payload);
            } else {
                return base44.entities.TimeAudit.create(payload);
            }
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['timeAudit'] });
            toast.success('Time audit saved!');
        }
    });

    const handleSave = () => {
        saveMutation.mutate(formData);
    };

    const addTask = () => {
        if (!newTask.task.trim() || !newTask.hours) {
            toast.error('Please enter task name and hours');
            return;
        }

        const task = {
            ...newTask,
            hours: parseFloat(newTask.hours),
            dollar_value: parseFloat(newTask.dollar_value) || calculateTaskValue(newTask.rating)
        };

        setFormData(prev => ({
            ...prev,
            tasks: [...prev.tasks, task]
        }));

        setNewTask({
            task: '',
            hours: '',
            dollar_value: '',
            rating: 'medium',
            delegate_to: ''
        });
    };

    const removeTask = (index) => {
        setFormData(prev => ({
            ...prev,
            tasks: prev.tasks.filter((_, i) => i !== index)
        }));
    };

    const calculateTaskValue = (rating) => {
        switch (rating) {
            case 'high': return formData.owner_rate;
            case 'medium': return formData.owner_rate * 0.5;
            case 'low': return formData.owner_rate * 0.2;
            default: return formData.owner_rate * 0.5;
        }
    };

    const getRatingColor = (rating) => {
        switch (rating) {
            case 'high': return 'bg-green-100 text-green-700 border-green-200';
            case 'medium': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
            case 'low': return 'bg-red-100 text-red-700 border-red-200';
            default: return 'bg-gray-100';
        }
    };

    // Calculate totals
    const totalHours = formData.tasks.reduce((sum, t) => sum + (parseFloat(t.hours) || 0), 0);
    const lowValueHours = formData.tasks.filter(t => t.rating === 'low').reduce((sum, t) => sum + (parseFloat(t.hours) || 0), 0);
    const totalValue = formData.tasks.reduce((sum, t) => sum + ((parseFloat(t.hours) || 0) * (parseFloat(t.dollar_value) || 0)), 0);
    const potentialSavings = lowValueHours * formData.owner_rate;

    // AI Analysis
    const getAIAnalysis = async () => {
        setAiLoading(true);
        try {
            const response = await base44.functions.invoke('workbookAICoach', {
                section: 'time-audit',
                action: 'analyze_tasks',
                current_answers: formData
            });

            if (response.data.analysis) {
                setAiAnalysis(response.data.analysis);
                toast.success('AI analysis complete!');
            }
        } catch (error) {
            toast.error('AI analysis unavailable');
        } finally {
            setAiLoading(false);
        }
    };

    if (isLoading) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50 flex items-center justify-center">
                <Loader2 className="w-8 h-8 animate-spin text-orange-600" />
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-amber-50 p-6">
            <div className="max-w-5xl mx-auto">
                {/* Header */}
                <div className="flex items-center justify-between mb-8">
                    <Button 
                        variant="ghost" 
                        onClick={() => navigate(createPageUrl('WorkbookDashboard'))}
                        className="gap-2"
                    >
                        <ArrowLeft className="w-4 h-4" />
                        Back to Workbook
                    </Button>
                    <Button onClick={handleSave} disabled={saveMutation.isPending} className="gap-2">
                        {saveMutation.isPending ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                            <Save className="w-4 h-4" />
                        )}
                        Save Progress
                    </Button>
                </div>

                {/* Title */}
                <div className="text-center mb-8">
                    <div className="inline-flex items-center gap-2 bg-orange-100 text-orange-700 px-4 py-2 rounded-full text-sm font-medium mb-4">
                        <Clock className="w-4 h-4" />
                        Section 4
                    </div>
                    <h1 className="text-3xl font-bold text-gray-900 mb-2">
                        Get Your Time Back
                    </h1>
                    <p className="text-gray-600">
                        Identify low-value tasks and reclaim hours for strategic work.
                    </p>
                </div>

                {/* Owner Rate Setting */}
                <Card className="mb-6">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <DollarSign className="w-5 h-5 text-green-600" />
                            Your Hourly Value
                        </CardTitle>
                        <CardDescription>
                            What is your time worth per hour as the owner? This helps calculate which tasks are below your pay grade.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="flex items-center gap-4">
                            <Label>$/hour:</Label>
                            <Input
                                type="number"
                                value={formData.owner_rate}
                                onChange={(e) => setFormData(prev => ({ ...prev, owner_rate: parseFloat(e.target.value) || 0 }))}
                                className="w-32"
                            />
                            <span className="text-sm text-gray-500">
                                Tasks below ${Math.round(formData.owner_rate * 0.3)}/hr should likely be delegated
                            </span>
                        </div>
                    </CardContent>
                </Card>

                {/* Summary Cards */}
                <div className="grid md:grid-cols-4 gap-4 mb-6">
                    <Card>
                        <CardContent className="pt-6">
                            <div className="text-sm text-gray-500 mb-1">Total Hours Logged</div>
                            <div className="text-3xl font-bold">{totalHours.toFixed(1)}</div>
                        </CardContent>
                    </Card>
                    <Card className="border-red-200 bg-red-50">
                        <CardContent className="pt-6">
                            <div className="text-sm text-red-600 mb-1">Low-Value Hours</div>
                            <div className="text-3xl font-bold text-red-700">{lowValueHours.toFixed(1)}</div>
                        </CardContent>
                    </Card>
                    <Card className="border-green-200 bg-green-50">
                        <CardContent className="pt-6">
                            <div className="text-sm text-green-600 mb-1">Potential Savings</div>
                            <div className="text-3xl font-bold text-green-700">${potentialSavings.toFixed(0)}</div>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardContent className="pt-6">
                            <div className="text-sm text-gray-500 mb-1">Hours to Reclaim</div>
                            <div className="text-3xl font-bold text-orange-600">{lowValueHours.toFixed(1)}+</div>
                        </CardContent>
                    </Card>
                </div>

                {/* Task Logger */}
                <Card className="mb-6">
                    <CardHeader>
                        <CardTitle>Task Value Assessment</CardTitle>
                        <CardDescription>
                            Log the tasks you do in a typical week and rate their value.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        {/* Add Task Form */}
                        <div className="grid md:grid-cols-6 gap-3 mb-4 p-4 bg-gray-50 rounded-lg">
                            <div className="md:col-span-2">
                                <Label className="mb-1 block text-xs">Task</Label>
                                <Input
                                    value={newTask.task}
                                    onChange={(e) => setNewTask(prev => ({ ...prev, task: e.target.value }))}
                                    placeholder="What task?"
                                />
                            </div>
                            <div>
                                <Label className="mb-1 block text-xs">Hours/Week</Label>
                                <Input
                                    type="number"
                                    value={newTask.hours}
                                    onChange={(e) => setNewTask(prev => ({ ...prev, hours: e.target.value }))}
                                    placeholder="2"
                                />
                            </div>
                            <div>
                                <Label className="mb-1 block text-xs">Value Level</Label>
                                <Select value={newTask.rating} onValueChange={(v) => setNewTask(prev => ({ ...prev, rating: v }))}>
                                    <SelectTrigger>
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="high">High (Only I can do)</SelectItem>
                                        <SelectItem value="medium">Medium</SelectItem>
                                        <SelectItem value="low">Low (Should delegate)</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div>
                                <Label className="mb-1 block text-xs">Delegate To</Label>
                                <Input
                                    value={newTask.delegate_to}
                                    onChange={(e) => setNewTask(prev => ({ ...prev, delegate_to: e.target.value }))}
                                    placeholder="Who?"
                                />
                            </div>
                            <div className="flex items-end">
                                <Button onClick={addTask} className="w-full gap-2">
                                    <Plus className="w-4 h-4" />
                                    Add
                                </Button>
                            </div>
                        </div>

                        {/* Task List */}
                        <div className="space-y-2">
                            {formData.tasks.length === 0 ? (
                                <div className="text-center py-8 text-gray-500">
                                    <Clock className="w-12 h-12 mx-auto mb-2 opacity-30" />
                                    <p>Start logging your tasks to see where your time goes.</p>
                                </div>
                            ) : (
                                formData.tasks.map((task, idx) => (
                                    <div key={idx} className={`flex items-center gap-4 p-3 rounded-lg border ${getRatingColor(task.rating)}`}>
                                        <div className="flex-1">
                                            <span className="font-medium">{task.task}</span>
                                        </div>
                                        <Badge variant="outline">{task.hours}hrs</Badge>
                                        <Badge variant="outline">${task.dollar_value}/hr</Badge>
                                        <Badge className={getRatingColor(task.rating)}>{task.rating}</Badge>
                                        {task.delegate_to && (
                                            <Badge variant="secondary">→ {task.delegate_to}</Badge>
                                        )}
                                        <Button 
                                            variant="ghost" 
                                            size="sm"
                                            onClick={() => removeTask(idx)}
                                            className="text-gray-400 hover:text-red-500"
                                        >
                                            <Trash2 className="w-4 h-4" />
                                        </Button>
                                    </div>
                                ))
                            )}
                        </div>
                    </CardContent>
                </Card>

                {/* AI Analysis */}
                <Card className="mb-6 bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-200">
                    <CardHeader>
                        <div className="flex items-center justify-between">
                            <div>
                                <CardTitle className="flex items-center gap-2">
                                    <Sparkles className="w-5 h-5 text-emerald-600" />
                                    AI Time Analysis
                                </CardTitle>
                                <CardDescription>
                                    Get AI-powered insights on how to reclaim your time.
                                </CardDescription>
                            </div>
                            <Button 
                                onClick={getAIAnalysis}
                                disabled={aiLoading || formData.tasks.length === 0}
                                className="gap-2"
                            >
                                {aiLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                                Analyze My Time
                            </Button>
                        </div>
                    </CardHeader>
                    {aiAnalysis && (
                        <CardContent className="space-y-4">
                            {aiAnalysis.delegate_immediately?.length > 0 && (
                                <div className="bg-white p-4 rounded-lg border">
                                    <h4 className="font-medium text-red-600 mb-2 flex items-center gap-2">
                                        <AlertCircle className="w-4 h-4" />
                                        Delegate Immediately
                                    </h4>
                                    <ul className="list-disc list-inside text-sm space-y-1">
                                        {aiAnalysis.delegate_immediately.map((item, i) => (
                                            <li key={i}>{item}</li>
                                        ))}
                                    </ul>
                                </div>
                            )}
                            {aiAnalysis.protect_and_expand?.length > 0 && (
                                <div className="bg-white p-4 rounded-lg border">
                                    <h4 className="font-medium text-green-600 mb-2 flex items-center gap-2">
                                        <TrendingUp className="w-4 h-4" />
                                        Protect & Expand (High Value)
                                    </h4>
                                    <ul className="list-disc list-inside text-sm space-y-1">
                                        {aiAnalysis.protect_and_expand.map((item, i) => (
                                            <li key={i}>{item}</li>
                                        ))}
                                    </ul>
                                </div>
                            )}
                            {aiAnalysis.hours_reclaimable && (
                                <div className="bg-orange-100 p-4 rounded-lg border border-orange-200 text-center">
                                    <p className="text-lg font-semibold text-orange-700">
                                        You could reclaim approximately {aiAnalysis.hours_reclaimable} hours per week!
                                    </p>
                                </div>
                            )}
                        </CardContent>
                    )}
                </Card>

                {/* What to Do With Time */}
                <Card className="mb-6">
                    <CardHeader>
                        <CardTitle>What Would You Do With Extra Time?</CardTitle>
                        <CardDescription>
                            If you could reclaim {lowValueHours.toFixed(1)}+ hours per week, what strategic work would you focus on?
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Textarea
                            value={formData.what_to_do_with_time}
                            onChange={(e) => setFormData(prev => ({ ...prev, what_to_do_with_time: e.target.value }))}
                            placeholder="I would spend more time on..."
                            className="min-h-[100px]"
                        />
                    </CardContent>
                </Card>

                {/* Completion */}
                <Card className="border-2 border-orange-300 bg-orange-50">
                    <CardContent className="pt-6 text-center">
                        <CheckCircle2 className="w-12 h-12 text-orange-500 mx-auto mb-4" />
                        <h3 className="text-xl font-semibold mb-2">Workbook Complete!</h3>
                        <p className="text-gray-600 mb-4">
                            You've worked through all four sections of the Pick One Workbook.
                            Return to the dashboard to review your progress and export your strategic plan.
                        </p>
                        <Button 
                            onClick={() => {
                                handleSave();
                                navigate(createPageUrl('WorkbookDashboard'));
                            }}
                            size="lg"
                            className="gap-2 bg-orange-600 hover:bg-orange-700"
                        >
                            <CheckCircle2 className="w-5 h-5" />
                            Complete & Return to Dashboard
                        </Button>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
