import React, { useState, useMemo, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import {
  Compass, ArrowLeft, ArrowRight, RotateCcw,
  Target, RefreshCw, TrendingUp, Zap,
  CheckCircle2, Lightbulb, HelpCircle, Sparkles,
  BookOpen, ChevronRight
} from 'lucide-react';

import { QUESTIONS, TOTAL_QUESTIONS } from '@/lib/strategyQuestions';
import { 
  initState, 
  applyAnswer, 
  calculateRecommendation,
  STRATEGY_META,
  STRATEGIES 
} from '@/lib/strategyEngine';

// =============================================================================
// CONSTANTS
// =============================================================================

const STORAGE_KEY = 'pickone_strategy_finder_v2';

const STRATEGY_ICONS = {
  CORE_VALUE: Compass,
  REVISE: RefreshCw,
  EXPAND: TrendingUp,
  DISRUPT: Zap,
};

const STRATEGY_COLORS = {
  CORE_VALUE: { bg: 'bg-blue-500', light: 'bg-blue-50', border: 'border-blue-200', text: 'text-blue-700' },
  REVISE: { bg: 'bg-green-500', light: 'bg-green-50', border: 'border-green-200', text: 'text-green-700' },
  EXPAND: { bg: 'bg-purple-500', light: 'bg-purple-50', border: 'border-purple-200', text: 'text-purple-700' },
  DISRUPT: { bg: 'bg-orange-500', light: 'bg-orange-50', border: 'border-orange-200', text: 'text-orange-700' },
};

// =============================================================================
// HELPER FUNCTIONS
// =============================================================================

function safeJsonParse(str, fallback = null) {
  try {
    return str ? JSON.parse(str) : fallback;
  } catch {
    return fallback;
  }
}

function saveState(data) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {}
}

function loadState() {
  return safeJsonParse(localStorage.getItem(STORAGE_KEY));
}

function clearState() {
  localStorage.removeItem(STORAGE_KEY);
}

// =============================================================================
// MAIN COMPONENT
// =============================================================================

export default function PickOneStrategyFinder() {
  const navigate = useNavigate();
  
  const { data: currentUser } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  // State
  const [phase, setPhase] = useState('intro'); // 'intro' | 'questions' | 'results'
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [engineState, setEngineState] = useState(() => initState());
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [result, setResult] = useState(null);

  // Load saved state on mount
  useEffect(() => {
    const saved = loadState();
    if (saved) {
      setPhase(saved.phase || 'intro');
      setCurrentQuestionIndex(saved.currentQuestionIndex || 0);
      setEngineState(saved.engineState || initState());
      setResult(saved.result || null);
    }
  }, []);

  // Save state on changes
  useEffect(() => {
    if (phase !== 'intro') {
      saveState({ phase, currentQuestionIndex, engineState, result });
    }
  }, [phase, currentQuestionIndex, engineState, result]);

  // Current question
  const currentQuestion = QUESTIONS[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / TOTAL_QUESTIONS) * 100;

  // =============================================================================
  // HANDLERS
  // =============================================================================

  const handleStart = () => {
    setPhase('questions');
    setCurrentQuestionIndex(0);
    setEngineState(initState());
    setSelectedAnswer(null);
    setResult(null);
  };

  const handleResume = () => {
    setPhase('questions');
  };

  const handleReset = () => {
    clearState();
    setPhase('intro');
    setCurrentQuestionIndex(0);
    setEngineState(initState());
    setSelectedAnswer(null);
    setResult(null);
  };

  const handleSelectAnswer = (answer) => {
    setSelectedAnswer(answer);
  };

  const handleNext = () => {
    if (!selectedAnswer) return;

    // Apply the answer to engine state
    const newState = applyAnswer(engineState, currentQuestion.id, selectedAnswer);
    setEngineState(newState);
    setSelectedAnswer(null);

    // Check if done
    if (currentQuestionIndex >= TOTAL_QUESTIONS - 1) {
      // Calculate results
      const recommendation = calculateRecommendation(newState);
      setResult(recommendation);
      setPhase('results');
      
      // Save diagnosis for workbook
      if (currentUser?.id) {
        localStorage.setItem(
          `pickone_diagnosis_${currentUser.id}`,
          JSON.stringify({
            strategy: recommendation.strategy,
            confidence: recommendation.confidence,
            scores: recommendation.scores,
            timestamp: new Date().toISOString(),
          })
        );
      }
    } else {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  const handleBack = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
      setSelectedAnswer(null);
    }
  };

  const handleContinueToWorkbook = () => {
    if (result?.strategyMeta?.nextPage) {
      navigate(createPageUrl(result.strategyMeta.nextPage));
    }
  };

  // =============================================================================
  // RENDER: INTRO PHASE
  // =============================================================================

  if (phase === 'intro') {
    const hasSavedProgress = loadState()?.engineState?.history?.length > 0;

    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50 p-6">
        <div className="max-w-2xl mx-auto pt-8">
          <div className="text-center mb-8">
            <Badge className="mb-4 bg-amber-100 text-amber-800">
              <Lightbulb className="w-3 h-3 mr-1" />
              Strategy Finder
            </Badge>
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Pick One
            </h1>
            <p className="text-xl text-gray-600 mb-2">
              Find the right strategy for your next 90 days
            </p>
          </div>

          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="space-y-4 text-gray-600">
                <p>
                  Every business faces different challenges. A florist who's losing customers 
                  needs a different strategy than one who can't keep up with demand.
                </p>
                <p>
                  This 6-question diagnostic will help you identify <strong>which ONE strategy</strong> 
                  deserves your focus for the next 90 days:
                </p>
                <div className="grid grid-cols-2 gap-3 py-4">
                  {Object.values(STRATEGIES).map(key => {
                    const meta = STRATEGY_META[key];
                    const Icon = STRATEGY_ICONS[key];
                    const colors = STRATEGY_COLORS[key];
                    return (
                      <div key={key} className={`flex items-center gap-3 p-3 rounded-lg ${colors.light}`}>
                        <div className={`w-10 h-10 rounded-lg ${colors.bg} flex items-center justify-center`}>
                          <Icon className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <div className="font-semibold text-gray-900">{meta.name}</div>
                          <div className="text-sm text-gray-500">{meta.tagline}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
                <p className="text-sm text-gray-500">
                  Takes about 2 minutes. Your answers are saved locally.
                </p>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-center gap-4">
            <Button size="lg" onClick={handleStart} className="gap-2">
              <Sparkles className="w-4 h-4" />
              Start Fresh
            </Button>
            {hasSavedProgress && (
              <Button size="lg" variant="outline" onClick={handleResume} className="gap-2">
                Continue Where I Left Off
              </Button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // =============================================================================
  // RENDER: QUESTIONS PHASE
  // =============================================================================

  if (phase === 'questions' && currentQuestion) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50 p-6">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="text-center mb-6 pt-4">
            <Badge className="mb-2 bg-blue-100 text-blue-800">
              Question {currentQuestionIndex + 1} of {TOTAL_QUESTIONS}
            </Badge>
          </div>

          {/* Progress */}
          <div className="mb-6">
            <Progress value={progress} className="h-2" />
          </div>

          {/* Question Card */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-xl leading-relaxed">
                {currentQuestion.question}
              </CardTitle>
              {currentQuestion.helpText && (
                <CardDescription className="flex items-start gap-2 mt-2">
                  <HelpCircle className="w-4 h-4 mt-0.5 flex-shrink-0 text-gray-400" />
                  {currentQuestion.helpText}
                </CardDescription>
              )}
            </CardHeader>
            <CardContent>
              <RadioGroup
                value={selectedAnswer?.value}
                onValueChange={(value) => {
                  const answer = currentQuestion.options.find(o => o.value === value);
                  handleSelectAnswer(answer);
                }}
                className="space-y-3"
              >
                {currentQuestion.options.map((option) => (
                  <div
                    key={option.value}
                    className={`
                      flex items-start space-x-3 p-4 rounded-lg border-2 cursor-pointer transition-all
                      ${selectedAnswer?.value === option.value
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'}
                    `}
                    onClick={() => handleSelectAnswer(option)}
                  >
                    <RadioGroupItem value={option.value} id={option.value} className="mt-1" />
                    <div className="flex-1">
                      <Label
                        htmlFor={option.value}
                        className="text-base font-medium cursor-pointer block"
                      >
                        {option.label}
                      </Label>
                      {option.description && (
                        <p className="text-sm text-gray-500 mt-1">{option.description}</p>
                      )}
                    </div>
                  </div>
                ))}
              </RadioGroup>
            </CardContent>
          </Card>

          {/* Navigation */}
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={handleBack}
              disabled={currentQuestionIndex === 0}
              className="gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>

            <Button
              onClick={handleNext}
              disabled={!selectedAnswer}
              className="gap-2"
            >
              {currentQuestionIndex === TOTAL_QUESTIONS - 1 ? 'See My Results' : 'Next'}
              <ArrowRight className="w-4 h-4" />
            </Button>
          </div>

          {/* Reset option */}
          <div className="text-center mt-8">
            <Button variant="ghost" size="sm" onClick={handleReset} className="text-gray-400">
              <RotateCcw className="w-3 h-3 mr-1" />
              Start Over
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // =============================================================================
  // RENDER: RESULTS PHASE
  // =============================================================================

  if (phase === 'results' && result) {
    const primary = result.strategyMeta;
    const PrimaryIcon = STRATEGY_ICONS[result.strategy];
    const primaryColors = STRATEGY_COLORS[result.strategy];
    const confidencePercent = Math.round(result.confidence * 100);

    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50 p-6">
        <div className="max-w-3xl mx-auto pt-8">
          {/* Header */}
          <div className="text-center mb-8">
            <Badge className="mb-4 bg-green-100 text-green-800">
              <CheckCircle2 className="w-3 h-3 mr-1" />
              Your Strategy Is Clear
            </Badge>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Focus on <span className={primaryColors.text}>{primary.name}</span>
            </h1>
            <p className="text-gray-600">
              {primary.tagline}
            </p>
          </div>

          {/* Primary Strategy Card */}
          <Card className={`mb-6 border-2 ${primaryColors.border} ${primaryColors.light}`}>
            <CardHeader className="text-center pb-4">
              <div className={`w-20 h-20 rounded-2xl ${primaryColors.bg} flex items-center justify-center mx-auto mb-4`}>
                <PrimaryIcon className="w-10 h-10 text-white" />
              </div>
              <div className="flex justify-center gap-2 mb-2">
                <Badge className="bg-white border">{confidencePercent}% Match</Badge>
              </div>
              <CardTitle className="text-2xl">{primary.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 mb-6 text-center max-w-xl mx-auto">
                {primary.description}
              </p>

              <div className="grid md:grid-cols-2 gap-6">
                {/* Signs This Is Right */}
                <div className={`p-4 rounded-lg bg-white border ${primaryColors.border}`}>
                  <h4 className="font-semibold mb-3 flex items-center gap-2">
                    <CheckCircle2 className={`w-4 h-4 ${primaryColors.text}`} />
                    Signs This Is Your Path
                  </h4>
                  <ul className="space-y-2">
                    {primary.symptoms.map((symptom, i) => (
                      <li key={i} className="text-sm text-gray-600 flex items-start gap-2">
                        <span className="text-green-500 mt-1">✓</span>
                        {symptom}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* 90-Day Focus */}
                <div className={`p-4 rounded-lg bg-white border ${primaryColors.border}`}>
                  <h4 className="font-semibold mb-3 flex items-center gap-2">
                    <Target className={`w-4 h-4 ${primaryColors.text}`} />
                    Your 90-Day Focus
                  </h4>
                  <ul className="space-y-2">
                    {primary.focus90Days.map((focus, i) => (
                      <li key={i} className="text-sm text-gray-600 flex items-start gap-2">
                        <span className="font-bold text-gray-400">{i + 1}.</span>
                        {focus}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* CTA */}
              <div className="mt-6 pt-6 border-t flex justify-center">
                <Button
                  size="lg"
                  onClick={handleContinueToWorkbook}
                  className={`gap-2 ${primaryColors.bg} hover:opacity-90`}
                >
                  Start {primary.name} Workbook
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Why This Recommendation */}
          {result.reasons?.length > 0 && (
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-amber-500" />
                  Why {primary.name}?
                </CardTitle>
                <CardDescription>
                  Based on your answers, here's what points to this strategy:
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {result.reasons.map((reason, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm">
                      <span className={`mt-0.5 font-bold ${primaryColors.text}`}>+{reason.points}</span>
                      <span className="text-gray-600">
                        You said "<span className="font-medium text-gray-900">{reason.answer}</span>"
                      </span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          {/* Score Breakdown */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-lg">Full Score Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {result.scores.map(({ strategy, score }) => {
                  const meta = STRATEGY_META[strategy];
                  const Icon = STRATEGY_ICONS[strategy];
                  const colors = STRATEGY_COLORS[strategy];
                  const maxScore = result.scores[0].score;
                  const percentage = maxScore > 0 ? (score / maxScore) * 100 : 0;

                  return (
                    <div key={strategy} className="flex items-center gap-3">
                      <Icon className={`w-5 h-5 ${colors.text}`} />
                      <span className="w-24 text-sm font-medium">{meta.name}</span>
                      <div className="flex-1 h-3 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className={`h-full ${colors.bg} transition-all duration-500`}
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                      <span className="w-8 text-sm text-gray-500 text-right font-mono">{score}</span>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Second Choice */}
          {result.secondChoice && result.secondChoice.score > 0 && (
            <Card className="mb-6 border border-gray-200">
              <CardContent className="py-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {(() => {
                      const SecondIcon = STRATEGY_ICONS[result.secondChoice.strategy];
                      const secondColors = STRATEGY_COLORS[result.secondChoice.strategy];
                      return (
                        <>
                          <div className={`w-10 h-10 rounded-lg ${secondColors.light} flex items-center justify-center`}>
                            <SecondIcon className={`w-5 h-5 ${secondColors.text}`} />
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Also Consider</p>
                            <p className="font-semibold">
                              {result.secondChoice.strategyMeta.name}: {result.secondChoice.strategyMeta.tagline}
                            </p>
                          </div>
                        </>
                      );
                    })()}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      // Override to second choice
                      const overrideResult = {
                        ...result,
                        strategy: result.secondChoice.strategy,
                        strategyMeta: result.secondChoice.strategyMeta,
                      };
                      setResult(overrideResult);
                    }}
                  >
                    Choose Instead
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Actions */}
          <div className="flex justify-center gap-4 mb-8">
            <Button variant="outline" onClick={handleReset} className="gap-2">
              <RotateCcw className="w-4 h-4" />
              Retake
            </Button>
            <Button
              variant="outline"
              onClick={() => navigate(createPageUrl('WorkbookDashboard'))}
              className="gap-2"
            >
              <BookOpen className="w-4 h-4" />
              Workbook Dashboard
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Fallback
  return (
    <div className="min-h-screen flex items-center justify-center">
      <Button onClick={handleReset}>Start Over</Button>
    </div>
  );
}
