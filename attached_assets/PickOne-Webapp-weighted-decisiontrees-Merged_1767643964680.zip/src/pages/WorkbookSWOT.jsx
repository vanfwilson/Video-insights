import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { 
    Grid3X3, ArrowLeft, ArrowRight, Save, Sparkles, 
    Loader2, CheckCircle2, Plus, Trash2, GripVertical,
    TrendingUp, TrendingDown, Shield, AlertTriangle,
    Building2, Target, Users, DollarSign, MapPin, Cpu, Package
} from 'lucide-react';

const BUSINESS_AREAS = [
    { id: 'overall', label: 'Overall Business', icon: Building2, description: 'Quick overview of your whole business' },
    { id: 'products_services', label: 'Products & Services', icon: Package, description: 'What you sell and deliver' },
    { id: 'marketing', label: 'Marketing', icon: Target, description: 'How you attract customers' },
    { id: 'sales', label: 'Sales', icon: Users, description: 'How you convert leads to customers' },
    { id: 'operations', label: 'Operations', icon: Building2, description: 'How you deliver your services' },
    { id: 'finance', label: 'Finance', icon: DollarSign, description: 'Cash flow, margins, profitability' },
    { id: 'territory', label: 'Territory', icon: MapPin, description: 'Geographic reach and market area' },
    { id: 'people', label: 'People', icon: Users, description: 'Team, culture, hiring' },
    { id: 'tech', label: 'Tech', icon: Cpu, description: 'Systems, software, equipment' },
    { id: 'assets', label: 'Assets', icon: Package, description: 'Physical and intellectual property' },
    { id: 'structure', label: 'Structure', icon: Building2, description: 'Organization and processes' }
];

const SWOT_CATEGORIES = [
    { id: 'strengths', label: 'Strengths', icon: TrendingUp, color: 'bg-blue-500', lightColor: 'bg-blue-50', borderColor: 'border-blue-200' },
    { id: 'weaknesses', label: 'Weaknesses', icon: TrendingDown, color: 'bg-red-500', lightColor: 'bg-red-50', borderColor: 'border-red-200' },
    { id: 'opportunities', label: 'Opportunities', icon: Shield, color: 'bg-green-500', lightColor: 'bg-green-50', borderColor: 'border-green-200' },
    { id: 'threats', label: 'Threats', icon: AlertTriangle, color: 'bg-orange-500', lightColor: 'bg-orange-50', borderColor: 'border-orange-200' }
];

const SWOTCard = ({ category, items, onAdd, onRemove, onUpdate }) => {
    const [newItem, setNewItem] = useState('');
    const CategoryIcon = category.icon;

    const handleAdd = () => {
        if (newItem.trim()) {
            onAdd({ text: newItem.trim(), priority: items.length + 1 });
            setNewItem('');
        }
    };

    return (
        <Card className={`${category.lightColor} ${category.borderColor} border-2`}>
            <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-lg">
                    <div className={`w-8 h-8 rounded-lg ${category.color} flex items-center justify-center`}>
                        <CategoryIcon className="w-4 h-4 text-white" />
                    </div>
                    {category.label}
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
                {/* Existing items */}
                {items.map((item, idx) => (
                    <div key={idx} className="flex items-start gap-2 bg-white rounded-lg p-2 border">
                        <GripVertical className="w-4 h-4 text-gray-400 mt-1 flex-shrink-0" />
                        <Input
                            value={item.text}
                            onChange={(e) => onUpdate(idx, { ...item, text: e.target.value })}
                            className="flex-1 border-0 p-0 h-auto text-sm focus-visible:ring-0"
                        />
                        <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => onRemove(idx)}
                            className="h-6 w-6 p-0 text-gray-400 hover:text-red-500"
                        >
                            <Trash2 className="w-3 h-3" />
                        </Button>
                    </div>
                ))}

                {/* Add new item */}
                <div className="flex gap-2">
                    <Input
                        value={newItem}
                        onChange={(e) => setNewItem(e.target.value)}
                        placeholder={`Add ${category.label.toLowerCase().slice(0, -1)}...`}
                        className="flex-1 text-sm"
                        onKeyPress={(e) => e.key === 'Enter' && handleAdd()}
                    />
                    <Button size="sm" onClick={handleAdd} className={category.color}>
                        <Plus className="w-4 h-4" />
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
};

export default function WorkbookSWOT() {
    const navigate = useNavigate();
    const queryClient = useQueryClient();
    const [activeArea, setActiveArea] = useState('overall');
    const [aiLoading, setAiLoading] = useState(false);

    // Form state - SWOT data by area
    const [swotData, setSwotData] = useState({});
    const [keyInsights, setKeyInsights] = useState({});

    const { data: currentUser } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me()
    });

    // Load existing SWOT analyses
    const { data: existingSWOTs, isLoading } = useQuery({
        queryKey: ['swotAnalyses', currentUser?.id],
        queryFn: async () => {
            const results = await base44.entities.SWOTAnalysis.filter({
                user_id: currentUser?.id
            });
            return results;
        },
        enabled: !!currentUser
    });

    // Initialize form with existing data
    useEffect(() => {
        if (existingSWOTs && existingSWOTs.length > 0) {
            const dataByArea = {};
            const insightsByArea = {};
            
            existingSWOTs.forEach(swot => {
                dataByArea[swot.business_area] = {
                    id: swot.id,
                    strengths: swot.strengths || [],
                    weaknesses: swot.weaknesses || [],
                    opportunities: swot.opportunities || [],
                    threats: swot.threats || []
                };
                insightsByArea[swot.business_area] = swot.key_insight || '';
            });
            
            setSwotData(dataByArea);
            setKeyInsights(insightsByArea);
        }
    }, [existingSWOTs]);

    // Get current area's SWOT data
    const currentSwot = swotData[activeArea] || {
        strengths: [],
        weaknesses: [],
        opportunities: [],
        threats: []
    };

    const updateSwotCategory = (category, newItems) => {
        setSwotData(prev => ({
            ...prev,
            [activeArea]: {
                ...prev[activeArea],
                [category]: newItems
            }
        }));
    };

    const handleAddItem = (category, item) => {
        const currentItems = currentSwot[category] || [];
        updateSwotCategory(category, [...currentItems, item]);
    };

    const handleRemoveItem = (category, index) => {
        const currentItems = currentSwot[category] || [];
        updateSwotCategory(category, currentItems.filter((_, i) => i !== index));
    };

    const handleUpdateItem = (category, index, updatedItem) => {
        const currentItems = currentSwot[category] || [];
        updateSwotCategory(category, currentItems.map((item, i) => i === index ? updatedItem : item));
    };

    // Save mutation
    const saveMutation = useMutation({
        mutationFn: async () => {
            const promises = Object.entries(swotData).map(async ([area, data]) => {
                const existingSwot = existingSWOTs?.find(s => s.business_area === area);
                
                const swotPayload = {
                    user_id: currentUser.id,
                    business_area: area,
                    strengths: data.strengths || [],
                    weaknesses: data.weaknesses || [],
                    opportunities: data.opportunities || [],
                    threats: data.threats || [],
                    key_insight: keyInsights[area] || '',
                    status: 'draft',
                    updated_at: new Date().toISOString()
                };

                if (existingSwot) {
                    return base44.entities.SWOTAnalysis.update(existingSwot.id, swotPayload);
                } else {
                    return base44.entities.SWOTAnalysis.create(swotPayload);
                }
            });

            return Promise.all(promises);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['swotAnalyses'] });
            toast.success('SWOT analysis saved!');
        },
        onError: (error) => {
            toast.error('Failed to save: ' + error.message);
        }
    });

    // AI suggestions
    const getAISuggestions = async () => {
        setAiLoading(true);
        try {
            const area = BUSINESS_AREAS.find(a => a.id === activeArea);
            const response = await base44.functions.invoke('workbookAICoach', {
                section: 'swot',
                action: 'suggest_swot_items',
                business_area: activeArea,
                area_label: area?.label,
                existing_items: currentSwot
            });

            if (response.data.suggestions) {
                // Merge suggestions with existing
                Object.entries(response.data.suggestions).forEach(([category, items]) => {
                    const currentItems = currentSwot[category] || [];
                    const newItems = items.filter(item => 
                        !currentItems.some(existing => existing.text.toLowerCase() === item.toLowerCase())
                    ).map((text, idx) => ({ text, priority: currentItems.length + idx + 1 }));
                    
                    if (newItems.length > 0) {
                        updateSwotCategory(category, [...currentItems, ...newItems]);
                    }
                });
                toast.success('AI suggestions added!');
            }
        } catch (error) {
            toast.error('AI suggestions unavailable');
        } finally {
            setAiLoading(false);
        }
    };

    const calculateCompletionByArea = (areaId) => {
        const data = swotData[areaId];
        if (!data) return 0;
        const totalItems = (data.strengths?.length || 0) + 
                         (data.weaknesses?.length || 0) + 
                         (data.opportunities?.length || 0) + 
                         (data.threats?.length || 0);
        return Math.min(100, totalItems * 8); // ~12-13 items = 100%
    };

    if (isLoading) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-50 flex items-center justify-center">
                <Loader2 className="w-8 h-8 animate-spin text-green-600" />
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50 p-6">
            <div className="max-w-7xl mx-auto">
                {/* Header */}
                <div className="flex items-center justify-between mb-8">
                    <Button 
                        variant="ghost" 
                        onClick={() => navigate(createPageUrl('WorkbookDashboard'))}
                        className="gap-2"
                    >
                        <ArrowLeft className="w-4 h-4" />
                        Back to Workbook
                    </Button>
                    <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending} className="gap-2">
                        {saveMutation.isPending ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                            <Save className="w-4 h-4" />
                        )}
                        Save Progress
                    </Button>
                </div>

                {/* Title */}
                <div className="text-center mb-8">
                    <div className="inline-flex items-center gap-2 bg-green-100 text-green-700 px-4 py-2 rounded-full text-sm font-medium mb-4">
                        <Grid3X3 className="w-4 h-4" />
                        Section 2
                    </div>
                    <h1 className="text-3xl font-bold text-gray-900 mb-2">
                        SWOT Analysis
                    </h1>
                    <p className="text-gray-600">
                        Analyze strengths, weaknesses, opportunities, and threats across your business.
                    </p>
                </div>

                {/* Area Tabs */}
                <Tabs value={activeArea} onValueChange={setActiveArea} className="space-y-6">
                    <Card>
                        <CardContent className="pt-6">
                            <TabsList className="flex flex-wrap gap-2 h-auto bg-transparent">
                                {BUSINESS_AREAS.map((area) => {
                                    const completion = calculateCompletionByArea(area.id);
                                    const AreaIcon = area.icon;
                                    return (
                                        <TabsTrigger 
                                            key={area.id} 
                                            value={area.id}
                                            className="flex items-center gap-2 data-[state=active]:bg-green-100 data-[state=active]:text-green-700"
                                        >
                                            <AreaIcon className="w-4 h-4" />
                                            {area.label}
                                            {completion > 0 && (
                                                <Badge variant="secondary" className="text-xs">
                                                    {completion}%
                                                </Badge>
                                            )}
                                        </TabsTrigger>
                                    );
                                })}
                            </TabsList>
                        </CardContent>
                    </Card>

                    {/* SWOT Content for Active Area */}
                    {BUSINESS_AREAS.map((area) => (
                        <TabsContent key={area.id} value={area.id} className="space-y-6">
                            {/* Area Header */}
                            <Card>
                                <CardHeader>
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <CardTitle className="flex items-center gap-2">
                                                <area.icon className="w-5 h-5" />
                                                {area.label}
                                            </CardTitle>
                                            <CardDescription>{area.description}</CardDescription>
                                        </div>
                                        <Button 
                                            onClick={getAISuggestions} 
                                            disabled={aiLoading}
                                            variant="outline"
                                            className="gap-2"
                                        >
                                            {aiLoading ? (
                                                <Loader2 className="w-4 h-4 animate-spin" />
                                            ) : (
                                                <Sparkles className="w-4 h-4" />
                                            )}
                                            AI Suggestions
                                        </Button>
                                    </div>
                                </CardHeader>
                            </Card>

                            {/* SWOT Grid */}
                            <div className="grid md:grid-cols-2 gap-6">
                                {SWOT_CATEGORIES.map((category) => (
                                    <SWOTCard
                                        key={category.id}
                                        category={category}
                                        items={currentSwot[category.id] || []}
                                        onAdd={(item) => handleAddItem(category.id, item)}
                                        onRemove={(idx) => handleRemoveItem(category.id, idx)}
                                        onUpdate={(idx, item) => handleUpdateItem(category.id, idx, item)}
                                    />
                                ))}
                            </div>

                            {/* Key Insight */}
                            <Card>
                                <CardHeader>
                                    <CardTitle>Key Insight from {area.label}</CardTitle>
                                    <CardDescription>
                                        What's the most important takeaway from this area's SWOT?
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <Textarea
                                        value={keyInsights[area.id] || ''}
                                        onChange={(e) => setKeyInsights(prev => ({ ...prev, [area.id]: e.target.value }))}
                                        placeholder="The biggest priority or pattern I see in this area is..."
                                        className="min-h-[100px]"
                                    />
                                </CardContent>
                            </Card>
                        </TabsContent>
                    ))}
                </Tabs>

                {/* Navigation */}
                <div className="flex items-center justify-between mt-8 pt-6 border-t">
                    <Button
                        variant="outline"
                        onClick={() => navigate(createPageUrl('WorkbookCoreValue'))}
                        className="gap-2"
                    >
                        <ArrowLeft className="w-4 h-4" />
                        Back to Core Value
                    </Button>
                    
                    <Button
                        onClick={() => {
                            saveMutation.mutate();
                            navigate(createPageUrl('WorkbookRootCause'));
                        }}
                        className="gap-2 bg-green-600 hover:bg-green-700"
                    >
                        Continue to Root Cause
                        <ArrowRight className="w-4 h-4" />
                    </Button>
                </div>
            </div>
        </div>
    );
}
