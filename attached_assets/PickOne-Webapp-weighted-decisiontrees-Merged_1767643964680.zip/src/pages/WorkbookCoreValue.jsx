import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { 
    Compass, ArrowLeft, ArrowRight, Save, Sparkles, 
    Loader2, CheckCircle2, MessageCircle, Lightbulb,
    Target, Heart, Users, Building2
} from 'lucide-react';

const STEPS = [
    { id: 1, title: 'Foundation', description: 'What shaped you and your business' },
    { id: 2, title: 'Reflection', description: 'Dig into the heart issues you solve' },
    { id: 3, title: 'Draft Your Core Value', description: 'Put it into words' },
    { id: 4, title: 'Alignment Check', description: 'Rate how your business reflects this value' }
];

const BUSINESS_AREAS = [
    { id: 'products', label: 'Products & Services', icon: Building2 },
    { id: 'marketing', label: 'Marketing', icon: Target },
    { id: 'sales', label: 'Sales', icon: Users },
    { id: 'operations', label: 'Operations', icon: Building2 },
    { id: 'finance', label: 'Finance', icon: Building2 },
    { id: 'territory', label: 'Territory', icon: Target },
    { id: 'people', label: 'People', icon: Users },
    { id: 'tech', label: 'Tech', icon: Building2 },
    { id: 'assets', label: 'Assets', icon: Building2 },
    { id: 'structure', label: 'Structure', icon: Building2 }
];

export default function WorkbookCoreValue() {
    const navigate = useNavigate();
    const queryClient = useQueryClient();
    const [currentStep, setCurrentStep] = useState(1);
    const [showAICoach, setShowAICoach] = useState(false);
    const [aiLoading, setAiLoading] = useState(false);
    const [aiSuggestions, setAiSuggestions] = useState([]);

    // Form state
    const [formData, setFormData] = useState({
        how_you_were_made: '',
        business_given: '',
        desire_for_customers: '',
        problems_you_solve: '',
        principle_at_heart: '',
        feelings_generated: '',
        core_value_draft_1: '',
        core_value_draft_2: '',
        core_value_final: '',
        alignment_scores: {}
    });

    const { data: currentUser } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me()
    });

    // Load existing data
    const { data: existingCoreValue, isLoading } = useQuery({
        queryKey: ['coreValue', currentUser?.id],
        queryFn: async () => {
            const results = await base44.entities.CoreValue.filter({
                user_id: currentUser?.id
            });
            return results[0] || null;
        },
        enabled: !!currentUser
    });

    // Initialize form with existing data
    useEffect(() => {
        if (existingCoreValue) {
            setFormData({
                how_you_were_made: existingCoreValue.how_you_were_made || '',
                business_given: existingCoreValue.business_given || '',
                desire_for_customers: existingCoreValue.desire_for_customers || '',
                problems_you_solve: existingCoreValue.problems_you_solve || '',
                principle_at_heart: existingCoreValue.principle_at_heart || '',
                feelings_generated: existingCoreValue.feelings_generated || '',
                core_value_draft_1: existingCoreValue.core_value_draft_1 || '',
                core_value_draft_2: existingCoreValue.core_value_draft_2 || '',
                core_value_final: existingCoreValue.core_value_final || '',
                alignment_scores: existingCoreValue.alignment_scores || {}
            });
            if (existingCoreValue.ai_suggestions) {
                setAiSuggestions(existingCoreValue.ai_suggestions);
            }
        }
    }, [existingCoreValue]);

    // Save mutation
    const saveMutation = useMutation({
        mutationFn: async (data) => {
            if (existingCoreValue) {
                return base44.entities.CoreValue.update(existingCoreValue.id, {
                    ...data,
                    updated_at: new Date().toISOString()
                });
            } else {
                return base44.entities.CoreValue.create({
                    user_id: currentUser.id,
                    ...data,
                    status: 'draft'
                });
            }
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['coreValue'] });
            toast.success('Progress saved!');
        },
        onError: (error) => {
            toast.error('Failed to save: ' + error.message);
        }
    });

    const handleSave = () => {
        saveMutation.mutate({
            ...formData,
            ai_suggestions: aiSuggestions
        });
    };

    const handleFieldChange = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleAlignmentChange = (areaId, value) => {
        setFormData(prev => ({
            ...prev,
            alignment_scores: {
                ...prev.alignment_scores,
                [areaId]: value[0]
            }
        }));
    };

    // AI Coach function
    const askAICoach = async (context) => {
        setAiLoading(true);
        try {
            const response = await base44.functions.invoke('workbookAICoach', {
                section: 'core-value',
                step: currentStep,
                context: context,
                current_answers: formData
            });

            if (response.data.suggestions) {
                setAiSuggestions(response.data.suggestions);
            }
            return response.data;
        } catch (error) {
            toast.error('AI Coach unavailable: ' + error.message);
            return null;
        } finally {
            setAiLoading(false);
        }
    };

    const generateCoreValueSuggestions = async () => {
        setAiLoading(true);
        try {
            const response = await base44.functions.invoke('workbookAICoach', {
                section: 'core-value',
                action: 'generate_suggestions',
                current_answers: formData
            });

            if (response.data.suggestions) {
                setAiSuggestions(response.data.suggestions);
                toast.success('AI generated core value suggestions!');
            }
        } catch (error) {
            toast.error('Failed to generate suggestions');
        } finally {
            setAiLoading(false);
        }
    };

    const calculateProgress = () => {
        const fields = [
            formData.how_you_were_made,
            formData.business_given,
            formData.desire_for_customers,
            formData.problems_you_solve,
            formData.principle_at_heart,
            formData.feelings_generated,
            formData.core_value_final
        ];
        const filled = fields.filter(f => f && f.trim().length > 0).length;
        return Math.round((filled / fields.length) * 100);
    };

    const calculateAlignmentAverage = () => {
        const scores = Object.values(formData.alignment_scores);
        if (scores.length === 0) return 0;
        return Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
    };

    if (isLoading) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex items-center justify-center">
                <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 p-6">
            <div className="max-w-4xl mx-auto">
                {/* Header */}
                <div className="flex items-center justify-between mb-8">
                    <Button 
                        variant="ghost" 
                        onClick={() => navigate(createPageUrl('WorkbookDashboard'))}
                        className="gap-2"
                    >
                        <ArrowLeft className="w-4 h-4" />
                        Back to Workbook
                    </Button>
                    <Button onClick={handleSave} disabled={saveMutation.isPending} className="gap-2">
                        {saveMutation.isPending ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                            <Save className="w-4 h-4" />
                        )}
                        Save Progress
                    </Button>
                </div>

                {/* Title Section */}
                <div className="text-center mb-8">
                    <div className="inline-flex items-center gap-2 bg-blue-100 text-blue-700 px-4 py-2 rounded-full text-sm font-medium mb-4">
                        <Compass className="w-4 h-4" />
                        Section 1
                    </div>
                    <h1 className="text-3xl font-bold text-gray-900 mb-2">
                        Find Your One Core Value
                    </h1>
                    <p className="text-gray-600">
                        Your core value is the heart of your business—the deeper issue you solve for your customers.
                    </p>
                </div>

                {/* Progress Bar */}
                <Card className="mb-8">
                    <CardContent className="pt-6">
                        <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-medium">Section Progress</span>
                            <span className="text-sm text-gray-500">{calculateProgress()}%</span>
                        </div>
                        <Progress value={calculateProgress()} className="h-2" />
                        
                        {/* Step Indicators */}
                        <div className="flex justify-between mt-6">
                            {STEPS.map((step) => (
                                <button
                                    key={step.id}
                                    onClick={() => setCurrentStep(step.id)}
                                    className={`flex flex-col items-center gap-2 p-2 rounded-lg transition-colors
                                        ${currentStep === step.id ? 'bg-blue-50' : 'hover:bg-gray-50'}
                                    `}
                                >
                                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium
                                        ${currentStep === step.id 
                                            ? 'bg-blue-600 text-white' 
                                            : currentStep > step.id 
                                                ? 'bg-green-500 text-white'
                                                : 'bg-gray-200 text-gray-600'
                                        }
                                    `}>
                                        {currentStep > step.id ? (
                                            <CheckCircle2 className="w-5 h-5" />
                                        ) : (
                                            step.id
                                        )}
                                    </div>
                                    <span className={`text-xs ${currentStep === step.id ? 'text-blue-600 font-medium' : 'text-gray-500'}`}>
                                        {step.title}
                                    </span>
                                </button>
                            ))}
                        </div>
                    </CardContent>
                </Card>

                {/* Step Content */}
                <div className="space-y-6">
                    {/* Step 1: Foundation */}
                    {currentStep === 1 && (
                        <>
                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <Heart className="w-5 h-5 text-red-500" />
                                        How Were You Made?
                                    </CardTitle>
                                    <CardDescription>
                                        What experiences, skills, and passions have shaped who you are?
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <Textarea
                                        value={formData.how_you_were_made}
                                        onChange={(e) => handleFieldChange('how_you_were_made', e.target.value)}
                                        placeholder="Think about your background, skills, experiences that led you to this business..."
                                        className="min-h-[120px]"
                                    />
                                </CardContent>
                            </Card>

                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <Building2 className="w-5 h-5 text-blue-500" />
                                        The Business You've Been Given
                                    </CardTitle>
                                    <CardDescription>
                                        Describe your business and what makes it unique.
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <Textarea
                                        value={formData.business_given}
                                        onChange={(e) => handleFieldChange('business_given', e.target.value)}
                                        placeholder="What is your business? What do you actually do day to day?"
                                        className="min-h-[120px]"
                                    />
                                </CardContent>
                            </Card>

                            <Card>
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <Users className="w-5 h-5 text-green-500" />
                                        Your Desire for Customers & Community
                                    </CardTitle>
                                    <CardDescription>
                                        What do you want for the people you serve?
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <Textarea
                                        value={formData.desire_for_customers}
                                        onChange={(e) => handleFieldChange('desire_for_customers', e.target.value)}
                                        placeholder="What impact do you want to have on your customers' lives?"
                                        className="min-h-[120px]"
                                    />
                                </CardContent>
                            </Card>
                        </>
                    )}

                    {/* Step 2: Reflection */}
                    {currentStep === 2 && (
                        <>
                            <Card>
                                <CardHeader>
                                    <CardTitle>What Problems Do You Really Solve?</CardTitle>
                                    <CardDescription>
                                        Go beyond the surface. What emotional or practical problems do you address?
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <Textarea
                                        value={formData.problems_you_solve}
                                        onChange={(e) => handleFieldChange('problems_you_solve', e.target.value)}
                                        placeholder="For a roofer it might be peace—both a peaceful experience and peace of mind. What is it for you?"
                                        className="min-h-[120px]"
                                    />
                                </CardContent>
                            </Card>

                            <Card>
                                <CardHeader>
                                    <CardTitle>What Principle Lies at the Heart?</CardTitle>
                                    <CardDescription>
                                        What value or principle guides how you solve these problems?
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <Textarea
                                        value={formData.principle_at_heart}
                                        onChange={(e) => handleFieldChange('principle_at_heart', e.target.value)}
                                        placeholder="Is it excellence? Integrity? Care? Connection? What's the core?"
                                        className="min-h-[120px]"
                                    />
                                </CardContent>
                            </Card>

                            <Card>
                                <CardHeader>
                                    <CardTitle>What Feelings Does Your Service Generate?</CardTitle>
                                    <CardDescription>
                                        How do customers feel after working with you?
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <Textarea
                                        value={formData.feelings_generated}
                                        onChange={(e) => handleFieldChange('feelings_generated', e.target.value)}
                                        placeholder="Relief? Confidence? Joy? Pride? Safety?"
                                        className="min-h-[120px]"
                                    />
                                </CardContent>
                            </Card>
                        </>
                    )}

                    {/* Step 3: Draft Core Value */}
                    {currentStep === 3 && (
                        <>
                            <Card className="border-2 border-blue-200 bg-blue-50/50">
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <Target className="w-5 h-5 text-blue-600" />
                                        Your Core Value Statement
                                    </CardTitle>
                                    <CardDescription>
                                        Put it all together in one clear phrase that captures the heart of your business.
                                    </CardDescription>
                                </CardHeader>
                                <CardContent className="space-y-6">
                                    <div>
                                        <Label className="mb-2 block">Draft 1</Label>
                                        <Input
                                            value={formData.core_value_draft_1}
                                            onChange={(e) => handleFieldChange('core_value_draft_1', e.target.value)}
                                            placeholder="First attempt at your core value..."
                                            className="text-lg"
                                        />
                                    </div>
                                    <div>
                                        <Label className="mb-2 block">Draft 2 (Refined)</Label>
                                        <Input
                                            value={formData.core_value_draft_2}
                                            onChange={(e) => handleFieldChange('core_value_draft_2', e.target.value)}
                                            placeholder="Refine it..."
                                            className="text-lg"
                                        />
                                    </div>
                                    <div className="pt-4 border-t">
                                        <Label className="mb-2 block text-lg font-semibold">Final Core Value</Label>
                                        <Input
                                            value={formData.core_value_final}
                                            onChange={(e) => handleFieldChange('core_value_final', e.target.value)}
                                            placeholder="Your one core value..."
                                            className="text-xl font-medium h-14"
                                        />
                                    </div>
                                </CardContent>
                            </Card>

                            {/* AI Suggestions */}
                            <Card className="bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-200">
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2">
                                        <Sparkles className="w-5 h-5 text-emerald-600" />
                                        AI Coach Suggestions
                                    </CardTitle>
                                    <CardDescription>
                                        Based on your answers, here are some core value ideas to consider.
                                    </CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <Button 
                                        onClick={generateCoreValueSuggestions}
                                        disabled={aiLoading}
                                        className="mb-4"
                                    >
                                        {aiLoading ? (
                                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        ) : (
                                            <Sparkles className="w-4 h-4 mr-2" />
                                        )}
                                        Generate Suggestions
                                    </Button>
                                    
                                    {aiSuggestions.length > 0 && (
                                        <div className="space-y-2">
                                            {aiSuggestions.map((suggestion, idx) => (
                                                <div 
                                                    key={idx}
                                                    className="p-3 bg-white rounded-lg border border-emerald-200 cursor-pointer hover:border-emerald-400 transition-colors"
                                                    onClick={() => handleFieldChange('core_value_draft_1', suggestion)}
                                                >
                                                    <p className="font-medium text-gray-900">{suggestion}</p>
                                                    <p className="text-xs text-emerald-600 mt-1">Click to use as Draft 1</p>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </CardContent>
                            </Card>
                        </>
                    )}

                    {/* Step 4: Alignment Check */}
                    {currentStep === 4 && (
                        <>
                            <Card className="mb-6">
                                <CardHeader>
                                    <CardTitle>Your Core Value</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="text-2xl font-semibold text-center py-4 px-6 bg-blue-50 rounded-lg">
                                        {formData.core_value_final || '(Complete Step 3 first)'}
                                    </div>
                                </CardContent>
                            </Card>

                            <Card>
                                <CardHeader>
                                    <CardTitle>Alignment Score by Business Area</CardTitle>
                                    <CardDescription>
                                        Rate how well each area of your business currently reflects your core value (1-10).
                                    </CardDescription>
                                </CardHeader>
                                <CardContent className="space-y-6">
                                    {BUSINESS_AREAS.map((area) => (
                                        <div key={area.id} className="space-y-2">
                                            <div className="flex items-center justify-between">
                                                <Label className="flex items-center gap-2">
                                                    <area.icon className="w-4 h-4 text-gray-500" />
                                                    {area.label}
                                                </Label>
                                                <Badge variant="outline">
                                                    {formData.alignment_scores[area.id] || 5}/10
                                                </Badge>
                                            </div>
                                            <Slider
                                                value={[formData.alignment_scores[area.id] || 5]}
                                                onValueChange={(value) => handleAlignmentChange(area.id, value)}
                                                min={1}
                                                max={10}
                                                step={1}
                                                className="w-full"
                                            />
                                        </div>
                                    ))}

                                    <div className="pt-6 border-t">
                                        <div className="flex items-center justify-between text-lg">
                                            <span className="font-semibold">Average Alignment Score</span>
                                            <Badge className="text-lg px-4 py-1" variant={
                                                calculateAlignmentAverage() >= 7 ? 'default' : 
                                                calculateAlignmentAverage() >= 5 ? 'secondary' : 'destructive'
                                            }>
                                                {calculateAlignmentAverage()}/10
                                            </Badge>
                                        </div>
                                        <p className="text-sm text-gray-500 mt-2">
                                            {calculateAlignmentAverage() >= 7 
                                                ? 'Great alignment! Your business reflects your core value well.'
                                                : calculateAlignmentAverage() >= 5
                                                    ? 'Good start. Focus on the lower-scoring areas in your planning.'
                                                    : 'There\'s work to do. This workbook will help you align your business with your core value.'
                                            }
                                        </p>
                                    </div>
                                </CardContent>
                            </Card>
                        </>
                    )}
                </div>

                {/* Navigation */}
                <div className="flex items-center justify-between mt-8 pt-6 border-t">
                    <Button
                        variant="outline"
                        onClick={() => setCurrentStep(Math.max(1, currentStep - 1))}
                        disabled={currentStep === 1}
                        className="gap-2"
                    >
                        <ArrowLeft className="w-4 h-4" />
                        Previous
                    </Button>
                    
                    {currentStep < 4 ? (
                        <Button
                            onClick={() => setCurrentStep(currentStep + 1)}
                            className="gap-2"
                        >
                            Next Step
                            <ArrowRight className="w-4 h-4" />
                        </Button>
                    ) : (
                        <Button
                            onClick={() => {
                                handleSave();
                                navigate(createPageUrl('WorkbookSWOT'));
                            }}
                            className="gap-2 bg-green-600 hover:bg-green-700"
                        >
                            Complete & Continue to SWOT
                            <CheckCircle2 className="w-4 h-4" />
                        </Button>
                    )}
                </div>
            </div>
        </div>
    );
}
