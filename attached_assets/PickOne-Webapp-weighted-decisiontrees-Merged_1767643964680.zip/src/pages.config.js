// =============================================================================
// PAGES CONFIG - MERGED VERSION
// =============================================================================
// Uses the merged PickOneStrategyFinder as the main diagnostic entry point
// =============================================================================

// Existing pages
import AdminDashboard from './pages/AdminDashboard';
import ClientSearch from './pages/ClientSearch';
import ClipManagement from './pages/ClipManagement';
import ClipPublisher from './pages/ClipPublisher';
import UserManagement from './pages/UserManagement';
import VideoReview from './pages/VideoReview';
import SemanticSearch from './pages/SemanticSearch';

// Pick One Workbook pages
import PickOneStrategyFinder from './pages/PickOneStrategyFinder'; // Merged diagnostic
import WorkbookDashboard from './pages/WorkbookDashboard';
import WorkbookCoreValue from './pages/WorkbookCoreValue';
import WorkbookSWOT from './pages/WorkbookSWOT';
import WorkbookRootCause from './pages/WorkbookRootCause';
import WorkbookTimeAudit from './pages/WorkbookTimeAudit';
import WorkbookActionPlan from './pages/WorkbookActionPlan';

import __Layout from './Layout.jsx';

export const PAGES = {
    // Existing pages
    "AdminDashboard": AdminDashboard,
    "ClientSearch": ClientSearch,
    "ClipManagement": ClipManagement,
    "ClipPublisher": ClipPublisher,
    "UserManagement": UserManagement,
    "VideoReview": VideoReview,
    "SemanticSearch": SemanticSearch,
    
    // Pick One pages
    "PickOneStrategyFinder": PickOneStrategyFinder,  // Main entry - merged diagnostic
    "WorkbookDashboard": WorkbookDashboard,
    "WorkbookCoreValue": WorkbookCoreValue,
    "WorkbookSWOT": WorkbookSWOT,
    "WorkbookRootCause": WorkbookRootCause,
    "WorkbookTimeAudit": WorkbookTimeAudit,
    "WorkbookActionPlan": WorkbookActionPlan,
}

export const pagesConfig = {
    mainPage: "AdminDashboard",
    Pages: PAGES,
    Layout: __Layout,
};
