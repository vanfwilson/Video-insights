// =============================================================================
// LAYOUT WITH STRATEGY FINDER + WORKBOOK NAVIGATION
// =============================================================================

import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { 
    Video, Search, Users, LogOut, BookOpen, 
    ChevronDown, Compass, Grid3X3, GitBranch, Clock, Target,
    Sparkles
} from 'lucide-react';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// Workbook section definitions for the dropdown
const WORKBOOK_SECTIONS = [
    { page: 'PickOneStrategyFinder', label: '🧭 Find Your Strategy', icon: Sparkles, highlight: true },
    null, // separator
    { page: 'WorkbookDashboard', label: 'Workbook Home', icon: BookOpen },
    { page: 'WorkbookCoreValue', label: 'Core Value', icon: Compass },
    { page: 'WorkbookSWOT', label: 'SWOT Analysis', icon: Grid3X3 },
    { page: 'WorkbookRootCause', label: 'Root Cause', icon: GitBranch },
    { page: 'WorkbookTimeAudit', label: 'Time Audit', icon: Clock },
    { page: 'WorkbookActionPlan', label: 'Action Plan', icon: Target },
];

export default function Layout({ children, currentPageName }) {
    const { data: currentUser } = useQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me()
    });

    const isAdmin = currentUser?.role === 'admin' || currentUser?.app_role === 'admin';
    const isCreator = isAdmin || currentUser?.app_role === 'creator';
    
    // Check if we're on a workbook/strategy page
    const isWorkbookPage = currentPageName?.startsWith('Workbook') || currentPageName === 'PickOneStrategyFinder';

    return (
        <div className="min-h-screen bg-gray-50">
            <nav className="bg-white border-b border-gray-200 shadow-sm">
                <div className="max-w-7xl mx-auto px-6 py-4">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-6">
                            <h1 className="text-xl font-bold text-gray-900">
                                {isWorkbookPage ? 'Pick One' : 'Video Hub'}
                            </h1>
                            <div className="flex gap-2">
                                {/* Video Hub Navigation */}
                                <Link to={createPageUrl('SemanticSearch')}>
                                    <Button variant={currentPageName === 'SemanticSearch' ? 'default' : 'ghost'} size="sm">
                                        <Search className="w-4 h-4 mr-2" />
                                        AI Search
                                    </Button>
                                </Link>
                                
                                {isCreator && (
                                    <Link to={createPageUrl('ClipManagement')}>
                                        <Button variant={currentPageName === 'ClipManagement' ? 'default' : 'ghost'} size="sm">
                                            <Video className="w-4 h-4 mr-2" />
                                            Clips
                                        </Button>
                                    </Link>
                                )}
                                
                                {isAdmin && (
                                    <>
                                        <Link to={createPageUrl('AdminDashboard')}>
                                            <Button variant={currentPageName === 'AdminDashboard' ? 'default' : 'ghost'} size="sm">
                                                <Video className="w-4 h-4 mr-2" />
                                                Dashboard
                                            </Button>
                                        </Link>
                                        <Link to={createPageUrl('UserManagement')}>
                                            <Button variant={currentPageName === 'UserManagement' ? 'default' : 'ghost'} size="sm">
                                                <Users className="w-4 h-4 mr-2" />
                                                Users
                                            </Button>
                                        </Link>
                                    </>
                                )}

                                {/* Divider */}
                                <div className="w-px h-8 bg-gray-200 mx-2" />

                                {/* Workbook Navigation Dropdown */}
                                <DropdownMenu>
                                    <DropdownMenuTrigger asChild>
                                        <Button 
                                            variant={isWorkbookPage ? 'default' : 'ghost'} 
                                            size="sm"
                                            className="gap-2"
                                        >
                                            <BookOpen className="w-4 h-4" />
                                            Pick One
                                            <ChevronDown className="w-3 h-3" />
                                        </Button>
                                    </DropdownMenuTrigger>
                                    <DropdownMenuContent align="start" className="w-56">
                                        <DropdownMenuLabel>Pick One Workbook</DropdownMenuLabel>
                                        <DropdownMenuSeparator />
                                        {WORKBOOK_SECTIONS.map((section, idx) => {
                                            if (section === null) {
                                                return <DropdownMenuSeparator key={idx} />;
                                            }
                                            const Icon = section.icon;
                                            return (
                                                <DropdownMenuItem key={section.page} asChild>
                                                    <Link 
                                                        to={createPageUrl(section.page)}
                                                        className={`flex items-center gap-2 cursor-pointer ${section.highlight ? 'font-semibold text-amber-700' : ''}`}
                                                    >
                                                        <Icon className="w-4 h-4" />
                                                        {section.label}
                                                    </Link>
                                                </DropdownMenuItem>
                                            );
                                        })}
                                    </DropdownMenuContent>
                                </DropdownMenu>
                            </div>
                        </div>
                        
                        <div className="flex items-center gap-4">
                            {currentUser && (
                                <>
                                    <div className="text-right">
                                        <div className="text-sm font-medium">
                                            {currentUser.full_name || currentUser.name || 'User'}
                                        </div>
                                        <div className="text-xs text-gray-500">
                                            {currentUser.app_role || currentUser.role || 'user'}
                                        </div>
                                    </div>
                                    <Button onClick={() => base44.auth.logout()} variant="outline" size="sm">
                                        <LogOut className="w-4 h-4" />
                                    </Button>
                                </>
                            )}
                        </div>
                    </div>
                </div>
            </nav>
            <main>
                {children}
            </main>
        </div>
    );
}
