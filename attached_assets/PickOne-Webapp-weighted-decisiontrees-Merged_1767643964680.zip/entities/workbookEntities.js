// =============================================================================
// WORKBOOK ENTITY SCHEMAS FOR BASE44/REPLIT
// =============================================================================
// Add these entities to your Base44 app or Replit database
// These define the data structure for storing workbook progress
// =============================================================================

// -----------------------------------------------------------------------------
// ENTITY: WorkbookProgress
// Tracks a user's overall progress through the workbook
// -----------------------------------------------------------------------------
export const WorkbookProgressSchema = {
    name: "WorkbookProgress",
    fields: {
        user_id: { type: "string", required: true },
        started_at: { type: "datetime", default: "now" },
        last_updated: { type: "datetime" },
        completed_sections: { type: "array", items: "string" }, // ['core-value', 'swot-quick', etc.]
        completion_percentage: { type: "number", default: 0 },
        status: { type: "string", enum: ["in_progress", "completed", "archived"], default: "in_progress" }
    },
    indexes: ["user_id", "status"]
};

// -----------------------------------------------------------------------------
// ENTITY: CoreValue
// Stores a user's core value discovery work
// -----------------------------------------------------------------------------
export const CoreValueSchema = {
    name: "CoreValue",
    fields: {
        user_id: { type: "string", required: true },
        workbook_id: { type: "string" }, // Link to WorkbookProgress
        
        // Step 1: Foundation questions
        how_you_were_made: { type: "text" },
        business_given: { type: "text" },
        desire_for_customers: { type: "text" },
        
        // Step 2: Reflection answers
        problems_you_solve: { type: "text" },
        principle_at_heart: { type: "text" },
        feelings_generated: { type: "text" },
        
        // Step 3: Core value drafts
        core_value_draft_1: { type: "string" },
        core_value_draft_2: { type: "string" },
        core_value_final: { type: "string" },
        
        // AI suggestions
        ai_suggestions: { type: "array", items: "string" },
        
        // Alignment scores (1-10 for each of 10 business areas)
        alignment_scores: { type: "json" }, // { products: 7, marketing: 5, ... }
        
        status: { type: "string", enum: ["draft", "complete"], default: "draft" },
        created_at: { type: "datetime", default: "now" },
        updated_at: { type: "datetime" }
    },
    indexes: ["user_id", "workbook_id"]
};

// -----------------------------------------------------------------------------
// ENTITY: SWOTAnalysis
// Stores SWOT analysis for each business area
// -----------------------------------------------------------------------------
export const SWOTAnalysisSchema = {
    name: "SWOTAnalysis",
    fields: {
        user_id: { type: "string", required: true },
        workbook_id: { type: "string" },
        
        // Business area this SWOT is for
        business_area: { 
            type: "string", 
            enum: [
                "overall", "products_services", "marketing", "sales", 
                "operations", "finance", "territory", "people", 
                "tech", "assets", "structure"
            ],
            required: true
        },
        
        // SWOT items (each is array of objects with text and priority)
        strengths: { type: "json" }, // [{ text: "...", priority: 1 }, ...]
        weaknesses: { type: "json" },
        opportunities: { type: "json" },
        threats: { type: "json" },
        
        // Key insight from this area
        key_insight: { type: "text" },
        key_metric: { type: "string" },
        
        // AI-detected patterns
        ai_patterns: { type: "array", items: "string" },
        
        status: { type: "string", enum: ["draft", "complete"], default: "draft" },
        created_at: { type: "datetime", default: "now" },
        updated_at: { type: "datetime" }
    },
    indexes: ["user_id", "workbook_id", "business_area"]
};

// -----------------------------------------------------------------------------
// ENTITY: RootCauseChart
// Stores root cause analysis work
// -----------------------------------------------------------------------------
export const RootCauseChartSchema = {
    name: "RootCauseChart",
    fields: {
        user_id: { type: "string", required: true },
        workbook_id: { type: "string" },
        
        // Problem flow chart
        before_triggers: { type: "text" },
        problem_description: { type: "text" },
        after_results: { type: "text" },
        
        // 5 Whys analysis
        five_whys: { type: "json" }, // [{ question: "Why?", answer: "..." }, ...]
        
        // Dig deep questions
        when_where_how: { type: "text" },
        who_affected: { type: "text" },
        when_not_issue: { type: "text" },
        what_driving: { type: "text" },
        conditions_worse: { type: "text" },
        how_stop_forever: { type: "text" },
        who_wins_loses: { type: "text" },
        what_stopping_us: { type: "text" },
        
        // Problem statement components
        symptom: { type: "text" },
        root_cause: { type: "text" },
        priority_impact: { type: "text" },
        
        // Final statement
        problem_statement: { type: "text" },
        
        // Affected areas (links to SWOT)
        affected_areas: { type: "array", items: "string" },
        
        // AI analysis
        ai_root_cause_suggestion: { type: "text" },
        
        status: { type: "string", enum: ["draft", "complete"], default: "draft" },
        created_at: { type: "datetime", default: "now" },
        updated_at: { type: "datetime" }
    },
    indexes: ["user_id", "workbook_id"]
};

// -----------------------------------------------------------------------------
// ENTITY: TimeAudit
// Stores time management assessment
// -----------------------------------------------------------------------------
export const TimeAuditSchema = {
    name: "TimeAudit",
    fields: {
        user_id: { type: "string", required: true },
        workbook_id: { type: "string" },
        
        // Task log entries
        tasks: { type: "json" }, // [{ task: "...", hours: 2, dollar_value: 50, rating: "low", delegate_to: "..." }, ...]
        
        // Summary calculations
        total_hours_logged: { type: "number" },
        high_value_hours: { type: "number" },
        medium_value_hours: { type: "number" },
        low_value_hours: { type: "number" },
        
        // Delegation plan
        tasks_to_delegate: { type: "json" }, // [{ task: "...", to: "...", training_needed: "..." }, ...]
        
        // Goals
        hours_to_reclaim: { type: "number" },
        what_to_do_with_time: { type: "text" },
        
        // Self-assessment
        time_management_rating: { type: "number" }, // 1-5
        biggest_time_wasters: { type: "array", items: "string" },
        
        status: { type: "string", enum: ["draft", "complete"], default: "draft" },
        created_at: { type: "datetime", default: "now" },
        updated_at: { type: "datetime" }
    },
    indexes: ["user_id", "workbook_id"]
};

// -----------------------------------------------------------------------------
// ENTITY: AICoachConversation
// Stores AI coaching conversations for context
// -----------------------------------------------------------------------------
export const AICoachConversationSchema = {
    name: "AICoachConversation",
    fields: {
        user_id: { type: "string", required: true },
        workbook_id: { type: "string" },
        section: { type: "string" }, // 'core-value', 'swot', 'root-cause', 'time-audit'
        
        messages: { type: "json" }, // [{ role: 'user'|'assistant', content: "...", timestamp: "..." }, ...]
        
        // Extracted insights from conversation
        key_insights: { type: "array", items: "string" },
        action_items: { type: "array", items: "string" },
        
        created_at: { type: "datetime", default: "now" },
        updated_at: { type: "datetime" }
    },
    indexes: ["user_id", "workbook_id", "section"]
};

// =============================================================================
// EXPORT ALL SCHEMAS
// =============================================================================
export const WorkbookEntities = {
    WorkbookProgress: WorkbookProgressSchema,
    CoreValue: CoreValueSchema,
    SWOTAnalysis: SWOTAnalysisSchema,
    RootCauseChart: RootCauseChartSchema,
    TimeAudit: TimeAuditSchema,
    AICoachConversation: AICoachConversationSchema
};

export default WorkbookEntities;
