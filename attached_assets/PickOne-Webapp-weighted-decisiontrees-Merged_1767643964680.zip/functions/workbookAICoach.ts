// =============================================================================
// WORKBOOK AI COACH FUNCTION
// =============================================================================
// Serverless function that provides AI coaching for Pick One workbook exercises
// Deploys to Base44/Replit functions
// =============================================================================

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

// Pick One knowledge base - core concepts from the book
const PICK_ONE_KNOWLEDGE = {
    coreValue: {
        definition: "A single, defining value that serves as the foundation for every decision, action, and interaction within the organization.",
        examples: [
            { industry: "Roofing", value: "Peace - both a peaceful experience and peace of mind that the roof won't leak" },
            { industry: "Florist", value: "Connection - helping people express love within relationships" },
            { industry: "Medical", value: "Restoration - helping people get their life back" },
            { industry: "Construction", value: "Trust - delivering what we promise, every time" },
            { industry: "HVAC", value: "Comfort - making homes feel like home" },
            { industry: "Plumbing", value: "Reliability - being there when it matters most" },
            { industry: "Electrical", value: "Safety - protecting families and businesses" },
            { industry: "Landscaping", value: "Pride - creating spaces people are proud to show off" }
        ],
        clarifyingQuestions: [
            "What keeps your best customers coming back?",
            "If your business disappeared tomorrow, what would customers miss most?",
            "What story do your happiest customers tell about working with you?",
            "When you've had your best days at work, what made them special?",
            "What problem did you originally start this business to solve?",
            "What do customers thank you for that goes beyond the basic service?",
            "What would a competitor have to offer to steal your best customers?"
        ]
    },
    swot: {
        commonStrengths: {
            trades: ["Experienced team", "Quality reputation", "Local knowledge", "Quick response time", "Strong customer relationships"],
            general: ["Established brand", "Skilled workforce", "Loyal customer base", "Financial stability", "Unique expertise"]
        },
        commonWeaknesses: {
            trades: ["Scheduling bottlenecks", "Inconsistent margins", "Key person dependency", "Limited marketing", "Cash flow timing"],
            general: ["Outdated processes", "High turnover", "Limited scalability", "Weak digital presence", "Communication gaps"]
        },
        commonOpportunities: {
            trades: ["Maintenance contracts", "Geographic expansion", "Service diversification", "Technology adoption", "Strategic partnerships"],
            general: ["New markets", "Digital transformation", "Strategic acquisitions", "New service lines", "Process automation"]
        },
        commonThreats: {
            trades: ["Labor shortage", "Material costs", "Economic downturn", "Low-cost competitors", "Regulatory changes"],
            general: ["Market disruption", "Changing regulations", "Economic uncertainty", "Talent competition", "Technology shifts"]
        }
    },
    rootCause: {
        fiveWhysGuidance: [
            "First 'Why' usually reveals symptoms",
            "Second 'Why' starts showing patterns",
            "Third 'Why' often reveals process issues",
            "Fourth 'Why' typically shows system problems",
            "Fifth 'Why' usually exposes root cause or culture"
        ],
        commonRootCauses: [
            "Unclear expectations or communication",
            "Missing or broken processes",
            "Wrong person in critical role",
            "Misaligned incentives",
            "Inadequate training or tools",
            "Competing priorities without clear direction"
        ]
    }
};

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { section, action, step, context, current_answers, business_area, area_label, existing_items } = await req.json();

        // Route to appropriate handler
        switch (section) {
            case 'core-value':
                return handleCoreValue(base44, action, step, current_answers, context);
            case 'swot':
                return handleSWOT(base44, action, business_area, area_label, existing_items);
            case 'root-cause':
                return handleRootCause(base44, action, current_answers, context);
            case 'time-audit':
                return handleTimeAudit(base44, action, current_answers);
            default:
                return Response.json({ error: 'Unknown section' }, { status: 400 });
        }
    } catch (error) {
        return Response.json({ 
            error: error.message,
            success: false 
        }, { status: 500 });
    }
});

async function handleCoreValue(base44, action, step, answers, context) {
    if (action === 'generate_suggestions') {
        // Generate core value suggestions based on user's answers
        const prompt = `You are a business coach helping a trades/construction business owner discover their core value.

Based on their answers:
- How they were made: ${answers.how_you_were_made || 'Not provided'}
- Their business: ${answers.business_given || 'Not provided'}  
- Desire for customers: ${answers.desire_for_customers || 'Not provided'}
- Problems they solve: ${answers.problems_you_solve || 'Not provided'}
- Principle at heart: ${answers.principle_at_heart || 'Not provided'}
- Feelings generated: ${answers.feelings_generated || 'Not provided'}

Generate 4 possible core value statements. Each should be:
- A single word or short phrase (2-4 words max)
- Focused on the emotional/heart impact, not the technical service
- Something that could guide every business decision

Examples of good core values: "Peace of mind", "Restoration", "Trust", "Connection", "Pride", "Reliability"

Return exactly 4 suggestions.`;

        const response = await base44.integrations.Core.InvokeLLM({
            prompt,
            response_json_schema: {
                type: 'object',
                properties: {
                    suggestions: {
                        type: 'array',
                        items: { type: 'string' },
                        minItems: 4,
                        maxItems: 4
                    }
                }
            }
        });

        return Response.json({
            success: true,
            suggestions: response.suggestions
        });
    }

    if (action === 'clarifying_question') {
        // Return a relevant clarifying question based on current step
        const questions = PICK_ONE_KNOWLEDGE.coreValue.clarifyingQuestions;
        const randomQuestion = questions[Math.floor(Math.random() * questions.length)];

        return Response.json({
            success: true,
            question: randomQuestion
        });
    }

    return Response.json({ error: 'Unknown action' }, { status: 400 });
}

async function handleSWOT(base44, action, businessArea, areaLabel, existingItems) {
    if (action === 'suggest_swot_items') {
        const prompt = `You are a business coach helping a trades/construction business analyze their ${areaLabel || businessArea} area.

Current items they've identified:
Strengths: ${existingItems?.strengths?.map(i => i.text).join(', ') || 'None yet'}
Weaknesses: ${existingItems?.weaknesses?.map(i => i.text).join(', ') || 'None yet'}
Opportunities: ${existingItems?.opportunities?.map(i => i.text).join(', ') || 'None yet'}
Threats: ${existingItems?.threats?.map(i => i.text).join(', ') || 'None yet'}

Suggest 2-3 additional items for each SWOT category that they may not have considered. Focus on:
- Industry-specific insights for trades/construction
- Practical, actionable items
- Things that commonly get overlooked

Return suggestions they DON'T already have listed.`;

        const response = await base44.integrations.Core.InvokeLLM({
            prompt,
            response_json_schema: {
                type: 'object',
                properties: {
                    suggestions: {
                        type: 'object',
                        properties: {
                            strengths: { type: 'array', items: { type: 'string' } },
                            weaknesses: { type: 'array', items: { type: 'string' } },
                            opportunities: { type: 'array', items: { type: 'string' } },
                            threats: { type: 'array', items: { type: 'string' } }
                        }
                    }
                }
            }
        });

        return Response.json({
            success: true,
            suggestions: response.suggestions
        });
    }

    if (action === 'detect_patterns') {
        // Analyze SWOT across all areas to find patterns
        const prompt = `Analyze these SWOT items across business areas and identify 3-5 key patterns or connections:

${JSON.stringify(existingItems, null, 2)}

Look for:
- Weaknesses that might be causing threats
- Strengths that could address opportunities
- Common themes across areas
- Potential root causes of multiple issues`;

        const response = await base44.integrations.Core.InvokeLLM({
            prompt,
            response_json_schema: {
                type: 'object',
                properties: {
                    patterns: {
                        type: 'array',
                        items: {
                            type: 'object',
                            properties: {
                                title: { type: 'string' },
                                description: { type: 'string' },
                                connected_items: { type: 'array', items: { type: 'string' } },
                                recommendation: { type: 'string' }
                            }
                        }
                    }
                }
            }
        });

        return Response.json({
            success: true,
            patterns: response.patterns
        });
    }

    return Response.json({ error: 'Unknown action' }, { status: 400 });
}

async function handleRootCause(base44, action, answers, context) {
    if (action === 'guide_five_whys') {
        const whyCount = answers?.five_whys?.length || 0;
        const lastAnswer = answers?.five_whys?.[whyCount - 1]?.answer || '';

        const prompt = `You are guiding a business owner through the "5 Whys" root cause analysis.

Problem being analyzed: ${answers?.problem_description || 'Not specified'}

Previous "Whys" answered:
${answers?.five_whys?.map((w, i) => `Why #${i + 1}: ${w.answer}`).join('\n') || 'None yet'}

Current "Why" number: ${whyCount + 1}

${PICK_ONE_KNOWLEDGE.rootCause.fiveWhysGuidance[whyCount] || ''}

Generate a follow-up "Why?" question that:
1. Builds on their last answer
2. Digs deeper toward root cause
3. Is specific and probing, not generic

Also indicate if you think they've reached a likely root cause (true/false).`;

        const response = await base44.integrations.Core.InvokeLLM({
            prompt,
            response_json_schema: {
                type: 'object',
                properties: {
                    next_question: { type: 'string' },
                    reached_root_cause: { type: 'boolean' },
                    root_cause_suggestion: { type: 'string' }
                }
            }
        });

        return Response.json({
            success: true,
            next_question: response.next_question,
            reached_root_cause: response.reached_root_cause,
            root_cause_suggestion: response.root_cause_suggestion
        });
    }

    if (action === 'generate_problem_statement') {
        const prompt = `Based on this root cause analysis, generate a clear problem statement.

Problem flow:
- Before/Triggers: ${answers?.before_triggers || 'Not specified'}
- Problem: ${answers?.problem_description || 'Not specified'}
- After/Results: ${answers?.after_results || 'Not specified'}

Five Whys analysis:
${answers?.five_whys?.map((w, i) => `Why #${i + 1}: ${w.answer}`).join('\n') || 'None'}

Additional context:
- Who is affected: ${answers?.who_affected || 'Not specified'}
- What's driving it: ${answers?.what_driving || 'Not specified'}

Create a root cause problem statement that includes:
1. The Symptom - What pain are they feeling?
2. The Root Cause - What's driving it beneath the surface?
3. Priority Impact - Which business areas are most affected?

Make it specific, actionable, and clear.`;

        const response = await base44.integrations.Core.InvokeLLM({
            prompt,
            response_json_schema: {
                type: 'object',
                properties: {
                    symptom: { type: 'string' },
                    root_cause: { type: 'string' },
                    priority_impact: { type: 'string' },
                    full_statement: { type: 'string' }
                }
            }
        });

        return Response.json({
            success: true,
            ...response
        });
    }

    return Response.json({ error: 'Unknown action' }, { status: 400 });
}

async function handleTimeAudit(base44, action, answers) {
    if (action === 'analyze_tasks') {
        const prompt = `Analyze this business owner's task list for time management opportunities.

Tasks logged:
${answers?.tasks?.map(t => `- ${t.task}: ${t.hours}hrs @ $${t.dollar_value}/hr (${t.rating})`).join('\n') || 'No tasks logged'}

Owner's stated hourly value: $${answers?.owner_rate || '150'}/hr

Identify:
1. Tasks that should definitely be delegated (below owner value)
2. Tasks that might be automated
3. Tasks that are high-value and should get MORE time
4. Estimated hours per week that could be reclaimed
5. Specific delegation recommendations`;

        const response = await base44.integrations.Core.InvokeLLM({
            prompt,
            response_json_schema: {
                type: 'object',
                properties: {
                    delegate_immediately: { type: 'array', items: { type: 'string' } },
                    consider_automation: { type: 'array', items: { type: 'string' } },
                    protect_and_expand: { type: 'array', items: { type: 'string' } },
                    hours_reclaimable: { type: 'number' },
                    delegation_plan: {
                        type: 'array',
                        items: {
                            type: 'object',
                            properties: {
                                task: { type: 'string' },
                                delegate_to: { type: 'string' },
                                training_needed: { type: 'string' }
                            }
                        }
                    }
                }
            }
        });

        return Response.json({
            success: true,
            analysis: response
        });
    }

    return Response.json({ error: 'Unknown action' }, { status: 400 });
}
