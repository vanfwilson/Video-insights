# Self-hosting (Linux server)

## Option A — run in dev mode (fastest)

Terminal 1:
```bash
cd server
npm install
npm run dev
```

Terminal 2:
```bash
npm install
cp .env.local.example .env.local
npm run dev
```

Open the Vite URL it prints (usually http://localhost:5173).

## Option B — Docker (production-ish)

1) Edit/build-time env vars for the frontend:
- `VITE_USE_LOCAL_API=true`
- `VITE_LOCAL_API_BASE_URL=http://<your-server-ip>:3001`

2) Build + run:
```bash
docker compose -f docker-compose.selfhost.yml build
docker compose -f docker-compose.selfhost.yml up -d
```

Frontend: http://<server>:8080  
API: http://<server>:3001/api/health

### Persistence
`./server/data/db.json` is the database file. It is volume-mounted in docker-compose.

## Auth (current)
The local server currently runs in **dev auth** mode (single seeded user).
Replace `/api/auth/*` with real auth (JWT, Google OAuth, etc.) when you are ready.
