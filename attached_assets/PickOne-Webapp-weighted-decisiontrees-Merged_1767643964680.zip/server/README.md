# Pick One Local API Server (self-host)

This server provides a lightweight, self-hostable replacement for the Base44 backend when running the app on your own Linux server.

- Storage: JSON file (`server/data/db.json`) via `lowdb`
- Auth: Dev-mode `auth/me` (no login yet)
- Entities: generic CRUD for workbook + video/clip objects
- Functions: `workbookAICoach`, `semanticSearch` (basic implementation)

## Run locally

```bash
cd server
npm install
npm run dev
```

Server listens on `http://localhost:3001` by default.
