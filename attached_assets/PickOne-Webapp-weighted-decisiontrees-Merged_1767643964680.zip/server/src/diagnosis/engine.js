// Decision-tree + scoring engine for Pick One (server-side)
// Designed to be deterministic and auditable (no AI required).
// You can later augment explanations with an LLM, but keep this as the source-of-truth.

export const STRATEGIES = Object.freeze({
  CORE_VALUE: "CORE_VALUE",
  REVISE: "REVISE",
  EXPAND: "EXPAND",
  DISRUPT: "DISRUPT",
});

export function initState(treeId) {
  return {
    treeId,
    currentQuestionId: null,
    answers: {},
    scores: {
      [STRATEGIES.CORE_VALUE]: 0,
      [STRATEGIES.REVISE]: 0,
      [STRATEGIES.EXPAND]: 0,
      [STRATEGIES.DISRUPT]: 0,
    },
    history: [], // [{questionId, answerId}]
  };
}

export function getQuestion(tree, questionId) {
  const q = tree.questions[questionId];
  if (!q) throw new Error(`Unknown questionId: ${questionId}`);
  return q;
}

export function applyAnswer(tree, state, questionId, answerId) {
  const q = getQuestion(tree, questionId);
  const a = q.answers.find((x) => x.id === answerId);
  if (!a) throw new Error(`Unknown answerId '${answerId}' for question '${questionId}'`);

  // copy state
  const next = {
    ...state,
    answers: { ...state.answers, [questionId]: answerId },
    scores: { ...state.scores },
    history: [...state.history, { questionId, answerId }],
  };

  if (a.score) {
    for (const [k, v] of Object.entries(a.score)) {
      if (next.scores[k] == null) continue;
      next.scores[k] += Number(v) || 0;
    }
  }

  return { nextState: next, nextQuestionId: a.next ?? null, flags: a.flags ?? [] };
}

export function recommend(state, tree) {
  const scores = state.scores;
  const entries = Object.entries(scores).sort((a, b) => b[1] - a[1]);
  const [top, topScore] = entries[0];
  const [, secondScore] = entries[1] || [null, 0];

  // confidence heuristic: margin vs total
  const total = Math.max(1, entries.reduce((s, [, v]) => s + Math.max(0, v), 0));
  const margin = topScore - secondScore;
  const confidence = clamp01(0.25 + 0.75 * (margin / Math.max(1, total)));

  const reasons = deriveReasons(state, tree, top);

  return {
    strategy: top,
    confidence,
    scores: entries.map(([k, v]) => ({ strategy: k, score: v })),
    reasons,
  };
}

// Determine what to ask next if answer doesn't explicitly route.
export function chooseNextQuestionId(tree, state, explicitNext) {
  if (explicitNext) return explicitNext;

  // If tree defines an ordering, follow the first unanswered question in order.
  if (Array.isArray(tree.order) && tree.order.length) {
    const unanswered = tree.order.find((qid) => state.answers[qid] == null);
    return unanswered ?? tree.finalizeId ?? null;
  }

  // Otherwise: find any unanswered question.
  const qids = Object.keys(tree.questions);
  const unanswered = qids.find((qid) => state.answers[qid] == null && qid !== tree.startId);
  return unanswered ?? tree.finalizeId ?? null;
}

function deriveReasons(state, tree, winningStrategy) {
  // Backtrace: which answers contributed the most to the winning strategy?
  const contributions = [];
  for (const { questionId, answerId } of state.history) {
    const q = tree.questions[questionId];
    if (!q) continue;
    const a = q.answers.find((x) => x.id === answerId);
    if (!a?.score?.[winningStrategy]) continue;
    contributions.push({
      questionId,
      question: q.prompt,
      answerId,
      answer: a.label,
      delta: a.score[winningStrategy],
      tag: a.tag ?? q.tag ?? null,
    });
  }
  contributions.sort((x, y) => (y.delta || 0) - (x.delta || 0));
  return contributions.slice(0, 6);
}

function clamp01(x) {
  return Math.max(0, Math.min(1, x));
}
