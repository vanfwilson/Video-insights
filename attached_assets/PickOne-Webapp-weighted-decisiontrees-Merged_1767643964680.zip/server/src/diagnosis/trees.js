// Pick One decision trees (server-side)
// Two trees:
// 1) pickone-map: mirrors your existing map diagram (fast entry)
// 2) pickone-v2: broader diagnostic tree using Fit/Flow/Future/Frontier framing

import { STRATEGIES } from "./engine.js";

const S = STRATEGIES;

export const trees = {
  "pickone-map": {
    id: "pickone-map",
    name: "Pick One Map (direct mirror)",
    startId: "start",
    finalizeId: "finalize",
    order: ["start", "values_focus", "issues_focus", "growth_focus", "profit_focus"],
    questions: {
      start: {
        id: "start",
        tag: "symptom",
        prompt: "Which statement feels MOST true right now?",
        answers: [
          { id: "void", label: "I feel a void / lack of purpose / no focus", score: { [S.CORE_VALUE]: 4 }, next: "values_focus", tag: "purpose" },
          { id: "cycle", label: "I'm stuck in a cycle of issues (same fires)", score: { [S.REVISE]: 4 }, next: "issues_focus", tag: "firefighting" },
          { id: "ceiling", label: "We have good systems but hit the ceiling", score: { [S.EXPAND]: 3, [S.REVISE]: 1 }, next: "growth_focus", tag: "plateau" },
          { id: "profit", label: "Low or no profit", score: { [S.REVISE]: 3, [S.CORE_VALUE]: 1 }, next: "profit_focus", tag: "profit" },
        ],
      },

      values_focus: {
        id: "values_focus",
        tag: "core-value",
        prompt: "When people pay you, what are they REALLY buying (the deeper outcome)?",
        answers: [
          { id: "unclear", label: "Not sure / it's hard to articulate", score: { [S.CORE_VALUE]: 4 }, next: "finalize", tag: "positioning" },
          { id: "clear", label: "Clear and consistent: customers buy a specific transformation/outcome", score: { [S.EXPAND]: 1 }, next: "finalize" },
          { id: "price", label: "Mostly price/convenience; I'm treated like a commodity", score: { [S.DISRUPT]: 2, [S.CORE_VALUE]: 2 }, next: "finalize", tag: "commoditized" },
        ],
      },

      issues_focus: {
        id: "issues_focus",
        tag: "revise",
        prompt: "What is the MAIN pattern behind your recurring issues?",
        answers: [
          { id: "capacity", label: "Capacity/throughput bottleneck (can't deliver fast enough)", score: { [S.REVISE]: 4 }, next: "finalize", tag: "constraint" },
          { id: "quality", label: "Inconsistent quality / rework / errors", score: { [S.REVISE]: 4 }, next: "finalize", tag: "quality" },
          { id: "cash", label: "Cashflow timing (AR/AP) / pricing/margins", score: { [S.REVISE]: 3, [S.CORE_VALUE]: 1 }, next: "finalize", tag: "cashflow" },
          { id: "people", label: "People/roles/accountability (team confusion)", score: { [S.REVISE]: 3 }, next: "finalize", tag: "team" },
        ],
      },

      growth_focus: {
        id: "growth_focus",
        tag: "expand",
        prompt: "If you doubled demand tomorrow, could you fulfill without breaking?",
        answers: [
          { id: "no", label: "No — we'd break (delivery, ops, quality)", score: { [S.REVISE]: 4 }, next: "finalize", tag: "ops" },
          { id: "yes", label: "Yes — we have capacity / could scale", score: { [S.EXPAND]: 4 }, next: "finalize", tag: "capacity" },
          { id: "maybe", label: "Maybe — depends on which service/product", score: { [S.EXPAND]: 2, [S.REVISE]: 2 }, next: "finalize" },
        ],
      },

      profit_focus: {
        id: "profit_focus",
        tag: "profit",
        prompt: "Where does profit leak MOST?",
        answers: [
          { id: "pricing", label: "Pricing too low / discounting / weak value narrative", score: { [S.CORE_VALUE]: 2, [S.REVISE]: 2 }, next: "finalize", tag: "pricing" },
          { id: "cost", label: "Costs too high / waste / rework", score: { [S.REVISE]: 4 }, next: "finalize", tag: "waste" },
          { id: "mix", label: "Product/service mix is wrong (doing too many low-margin things)", score: { [S.REVISE]: 3, [S.CORE_VALUE]: 1 }, next: "finalize", tag: "mix" },
          { id: "market", label: "Market is crowded / race-to-the-bottom", score: { [S.DISRUPT]: 3, [S.CORE_VALUE]: 1 }, next: "finalize", tag: "crowded" },
        ],
      },

      finalize: {
        id: "finalize",
        tag: "finalize",
        prompt: "Finalize",
        answers: [{ id: "done", label: "Done", score: {} }],
      },
    },
  },

  "pickone-v2": {
    id: "pickone-v2",
    name: "Pick One V2 (Fit / Flow / Future / Frontier)",
    startId: "q0",
    finalizeId: "finalize",
    // ordering is a fallback; branching usually handles it
    order: ["q0", "q1", "q2", "q3", "q4", "q5", "q6", "q7", "q8", "q9", "q10"],
    questions: {
      q0: {
        id: "q0",
        tag: "triage",
        prompt: "What is the most urgent pain RIGHT NOW?",
        answers: [
          { id: "no_demand", label: "Not enough customers / inconsistent demand", score: { [S.CORE_VALUE]: 2, [S.EXPAND]: 1 }, next: "q1", tag: "demand" },
          { id: "no_profit", label: "Revenue exists but profit is weak or negative", score: { [S.REVISE]: 2, [S.CORE_VALUE]: 1 }, next: "q4", tag: "profit" },
          { id: "overwhelmed", label: "Too many fires / delivery chaos / bottlenecks", score: { [S.REVISE]: 3 }, next: "q6", tag: "ops" },
          { id: "plateau", label: "Stable business but growth has stalled", score: { [S.EXPAND]: 2, [S.DISRUPT]: 1 }, next: "q8", tag: "plateau" },
          { id: "identity", label: "I’m not sure what we stand for / why we matter", score: { [S.CORE_VALUE]: 4 }, next: "q2", tag: "purpose" },
        ],
      },

      // FIT (positioning / JTBD / core value)
      q1: {
        id: "q1",
        tag: "fit",
        prompt: "When you DO win customers, why do they choose you?",
        answers: [
          { id: "unclear", label: "Unclear — mostly price, convenience, or random", score: { [S.CORE_VALUE]: 4 }, next: "q2", tag: "positioning" },
          { id: "clear", label: "Clear — a specific outcome/transformation they value", score: { [S.EXPAND]: 1 }, next: "q3" },
          { id: "referrals", label: "Referrals only; we can’t predictably generate demand", score: { [S.EXPAND]: 3, [S.CORE_VALUE]: 1 }, next: "q3", tag: "channel" },
        ],
      },

      q2: {
        id: "q2",
        tag: "core-value",
        prompt: "Does your offer feel like a COMMODITY (customers struggle to see why you’re different)?",
        answers: [
          { id: "yes", label: "Yes — I’m compared like a commodity", score: { [S.CORE_VALUE]: 3, [S.DISRUPT]: 2 }, next: "q3", tag: "commoditized" },
          { id: "no", label: "No — we’re clearly different", score: { [S.EXPAND]: 1 }, next: "q3" },
          { id: "not_sure", label: "Not sure", score: { [S.CORE_VALUE]: 3 }, next: "q3" },
        ],
      },

      q3: {
        id: "q3",
        tag: "fit",
        prompt: "If you had to describe the 'job' customers hire you to do (in one sentence), can you?",
        answers: [
          { id: "no", label: "No — we need language and clarity", score: { [S.CORE_VALUE]: 4 }, next: "q4", tag: "jtbd" },
          { id: "yes", label: "Yes", score: { [S.EXPAND]: 1 }, next: "q4" },
          { id: "multiple", label: "We do too many unrelated things", score: { [S.REVISE]: 2, [S.CORE_VALUE]: 2 }, next: "q4", tag: "focus" },
        ],
      },

      // PROFIT (pricing / costs / mix)
      q4: {
        id: "q4",
        tag: "profit",
        prompt: "Which is the BIGGER driver of low profit?",
        answers: [
          { id: "pricing", label: "Pricing / discounting / weak value narrative", score: { [S.CORE_VALUE]: 2, [S.REVISE]: 2 }, next: "q5", tag: "pricing" },
          { id: "costs", label: "Costs / waste / rework / inefficiency", score: { [S.REVISE]: 4 }, next: "q6", tag: "waste" },
          { id: "mix", label: "Bad product/service mix (low-margin work dominates)", score: { [S.REVISE]: 3, [S.CORE_VALUE]: 1 }, next: "q6", tag: "mix" },
        ],
      },

      q5: {
        id: "q5",
        tag: "market",
        prompt: "Is the MARKET crowded and price-driven?",
        answers: [
          { id: "yes", label: "Yes — buyers shop purely on price", score: { [S.DISRUPT]: 3, [S.CORE_VALUE]: 1 }, next: "q8", tag: "crowded" },
          { id: "no", label: "No — buyers care about value and outcomes", score: { [S.CORE_VALUE]: 1 }, next: "q6" },
          { id: "depends", label: "Depends on segment", score: { [S.EXPAND]: 1, [S.CORE_VALUE]: 1 }, next: "q6" },
        ],
      },

      // FLOW (constraints / TOC / revise)
      q6: {
        id: "q6",
        tag: "flow",
        prompt: "Where is the main BOTTLENECK right now?",
        answers: [
          { id: "sales", label: "Sales pipeline / lead flow", score: { [S.EXPAND]: 2, [S.CORE_VALUE]: 1 }, next: "q8", tag: "pipeline" },
          { id: "delivery", label: "Delivery capacity / throughput", score: { [S.REVISE]: 4 }, next: "q7", tag: "throughput" },
          { id: "quality", label: "Quality / rework / errors", score: { [S.REVISE]: 4 }, next: "q7", tag: "quality" },
          { id: "people", label: "People/roles/accountability", score: { [S.REVISE]: 3 }, next: "q7", tag: "team" },
          { id: "cash", label: "Cash conversion cycle / AR/AP timing", score: { [S.REVISE]: 3 }, next: "q7", tag: "cashflow" },
        ],
      },

      q7: {
        id: "q7",
        tag: "revise",
        prompt: "If you fixed ONE internal thing in 30 days, which would create the biggest ripple?",
        answers: [
          { id: "process", label: "Process standardization (SOPs/checklists)", score: { [S.REVISE]: 3 }, next: "q8" },
          { id: "pricing", label: "Raise prices / repackage offer / reduce low-value work", score: { [S.REVISE]: 2, [S.CORE_VALUE]: 1 }, next: "q8" },
          { id: "tools", label: "Tools/automation to remove manual work", score: { [S.REVISE]: 2 }, next: "q8" },
          { id: "hiring", label: "Hire/role clarity/accountability", score: { [S.REVISE]: 3 }, next: "q8" },
        ],
      },

      // FUTURE (growth / Ansoff-ish expand)
      q8: {
        id: "q8",
        tag: "future",
        prompt: "Which growth lever is MOST realistic in 90 days?",
        answers: [
          { id: "penetration", label: "Sell more to existing market (better marketing/sales execution)", score: { [S.EXPAND]: 3 }, next: "q9", tag: "ansoff_penetration" },
          { id: "new_market", label: "Take existing offer to a new market/channel/geo", score: { [S.EXPAND]: 3 }, next: "q9", tag: "ansoff_market_dev" },
          { id: "new_offer", label: "Create a new offer for existing customers", score: { [S.EXPAND]: 2, [S.DISRUPT]: 1 }, next: "q9", tag: "ansoff_product_dev" },
          { id: "none", label: "None — something feels fundamentally off", score: { [S.CORE_VALUE]: 2, [S.DISRUPT]: 2 }, next: "q10" },
        ],
      },

      // FRONTIER (disrupt / blue-ocean / model shifts)
      q9: {
        id: "q9",
        tag: "frontier",
        prompt: "Do you believe your current model is becoming obsolete (tech shift, platform change, new competitor model)?",
        answers: [
          { id: "yes", label: "Yes — the game is changing", score: { [S.DISRUPT]: 4 }, next: "q10", tag: "model_shift" },
          { id: "no", label: "No — fundamentals still work", score: { [S.REVISE]: 1, [S.EXPAND]: 1 }, next: "q10" },
          { id: "not_sure", label: "Not sure", score: { [S.DISRUPT]: 2 }, next: "q10" },
        ],
      },

      q10: {
        id: "q10",
        tag: "integration",
        prompt: "If you pick the wrong strategy, what is the biggest risk?",
        answers: [
          { id: "waste_time", label: "Wasting time on the wrong work", score: { [S.CORE_VALUE]: 1 }, next: "finalize" },
          { id: "cash", label: "Running out of cash", score: { [S.REVISE]: 2 }, next: "finalize" },
          { id: "miss_growth", label: "Missing growth window", score: { [S.EXPAND]: 2 }, next: "finalize" },
          { id: "irrelevant", label: "Becoming irrelevant", score: { [S.DISRUPT]: 2 }, next: "finalize" },
        ],
      },

      finalize: {
        id: "finalize",
        tag: "finalize",
        prompt: "Finalize",
        answers: [{ id: "done", label: "Done", score: {} }],
      },
    },
  },
};

export function getTree(treeId = "pickone-v2") {
  const t = trees[treeId];
  if (!t) throw new Error(`Unknown treeId: ${treeId}`);
  return t;
}
