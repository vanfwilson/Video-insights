import { getTree } from "./trees.js";
import { initState, getQuestion, applyAnswer, chooseNextQuestionId, recommend } from "./engine.js";

export function validateTree(treeId="pickone-v2") {
  const tree = getTree(treeId);
  const qids = Object.keys(tree.questions);
  if (!tree.startId || !tree.questions[tree.startId]) throw new Error("Missing startId question");
  if (!tree.finalizeId || !tree.questions[tree.finalizeId]) throw new Error("Missing finalizeId question");

  for (const qid of qids) {
    const q = tree.questions[qid];
    if (!q.prompt || !Array.isArray(q.answers) || q.answers.length === 0) {
      throw new Error(`Invalid question '${qid}'`);
    }
    for (const a of q.answers) {
      if (!a.id || !a.label) throw new Error(`Invalid answer in '${qid}'`);
      if (a.next && !tree.questions[a.next]) throw new Error(`Answer '${qid}.${a.id}' routes to missing question '${a.next}'`);
    }
  }
  return { ok: true, questions: qids.length };
}

// quick smoke-run
if (import.meta.url === `file://${process.argv[1]}`) {
  const treeId = process.argv[2] || "pickone-v2";
  console.log("Validating", treeId);
  console.log(validateTree(treeId));

  const tree = getTree(treeId);
  let state = initState(treeId);
  let qid = tree.startId;
  for (let i=0; i<20; i++) {
    const q = getQuestion(tree, qid);
    const a = q.answers[0]; // pick first answer for smoke
    const { nextState, nextQuestionId } = applyAnswer(tree, state, qid, a.id);
    state = nextState;
    qid = chooseNextQuestionId(tree, state, nextQuestionId) || tree.finalizeId;
    if (qid === tree.finalizeId) break;
  }
  console.log("Recommendation", recommend(state, tree));
}
