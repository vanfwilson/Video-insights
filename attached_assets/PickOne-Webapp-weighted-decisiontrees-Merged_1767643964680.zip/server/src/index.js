import express from "express";
import cors from "cors";
import { Low } from "lowdb";
import { JSONFile } from "lowdb/node";
import { nanoid } from "nanoid";
import { getTree } from "./diagnosis/trees.js";
import { initState, getQuestion, applyAnswer, chooseNextQuestionId, recommend } from "./diagnosis/engine.js";

const PORT = process.env.PORT ? Number(process.env.PORT) : 3001;
const DB_PATH = process.env.DB_PATH || new URL("../data/db.json", import.meta.url).pathname;

const adapter = new JSONFile(DB_PATH);
const db = new Low(adapter, {
  users: [],
  WorkbookProgress: [],
  CoreValue: [],
  SWOTAnalysis: [],
  RootCauseChart: [],
  TimeAudit: [],
  AICoachConversation: [],
  Video: [],
  Clip: [],
  Topic: [],
});

async function initDb() {
  await db.read();
  // Ensure all collections exist
  for (const key of Object.keys(db.data)) {
    if (!db.data[key]) db.data[key] = [];
  }
  // Seed a default user if none exists
  if (!Array.isArray(db.data.users) || db.data.users.length === 0) {
    db.data.users = [{ id: "local-user", email: "local@example.com", name: "Local User", role: "admin" }];
  }
  await db.write();
}

// -----------------------------------------------------------------------------
// Helpers
// -----------------------------------------------------------------------------
function nowIso() {
  return new Date().toISOString();
}

function getCollectionName(entity) {
  // Entity names in the frontend are PascalCase already
  if (!db.data[entity]) {
    db.data[entity] = [];
  }
  return entity;
}

function parseFilter(query) {
  // equality-only filter from query string (?user_id=...&status=...)
  const filter = {};
  for (const [k, v] of Object.entries(query || {})) {
    if (v === undefined) continue;
    filter[k] = String(v);
  }
  return filter;
}

function applyFilter(items, filter) {
  const keys = Object.keys(filter);
  if (keys.length === 0) return items;
  return items.filter((it) => keys.every((k) => String(it?.[k] ?? "") === String(filter[k])));
}

function toEntityResponse(item) {
  // Match Base44 entities having id + timestamps
  return item;
}

// -----------------------------------------------------------------------------
// App
// -----------------------------------------------------------------------------
const app = express();
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: "10mb" }));

app.get("/api/health", async (_req, res) => {
  res.json({ ok: true, time: nowIso() });
});

// Dev auth (replace with real auth later)
app.get("/api/auth/me", async (_req, res) => {
  await db.read();
  const user = db.data.users[0];
  res.json(user);
});

app.post("/api/auth/logout", async (_req, res) => {
  res.json({ success: true });
});

// Generic entity CRUD
app.get("/api/entities/:entity", async (req, res) => {
  await db.read();
  const entity = getCollectionName(req.params.entity);
  const filter = parseFilter(req.query);
  const items = applyFilter(db.data[entity] || [], filter);
  res.json(items.map(toEntityResponse));
});

app.post("/api/entities/:entity", async (req, res) => {
  await db.read();
  const entity = getCollectionName(req.params.entity);
  const item = {
    id: nanoid(),
    created_at: nowIso(),
    updated_at: nowIso(),
    ...req.body,
  };
  db.data[entity].push(item);
  await db.write();
  res.json(toEntityResponse(item));
});

app.get("/api/entities/:entity/:id", async (req, res) => {
  await db.read();
  const entity = getCollectionName(req.params.entity);
  const item = (db.data[entity] || []).find((x) => x.id === req.params.id);
  if (!item) return res.status(404).json({ error: "Not found" });
  res.json(toEntityResponse(item));
});

app.patch("/api/entities/:entity/:id", async (req, res) => {
  await db.read();
  const entity = getCollectionName(req.params.entity);
  const idx = (db.data[entity] || []).findIndex((x) => x.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: "Not found" });
  const existing = db.data[entity][idx];
  const updated = { ...existing, ...req.body, updated_at: nowIso() };
  db.data[entity][idx] = updated;
  await db.write();
  res.json(toEntityResponse(updated));
});

app.delete("/api/entities/:entity/:id", async (req, res) => {
  await db.read();
  const entity = getCollectionName(req.params.entity);
  const before = db.data[entity].length;
  db.data[entity] = (db.data[entity] || []).filter((x) => x.id !== req.params.id);
  await db.write();
  res.json({ success: true, deleted: before - db.data[entity].length });
});

// Functions (Base44-compatible-ish)
app.post("/api/functions/:name", async (req, res) => {
  const name = req.params.name;

  if (name === "workbookAICoach") {
    // Very lightweight, deterministic coach (you can swap to OpenAI later)
    const { section, action, step, current_answers = {}, context = {} } = req.body || {};

    const response = {
      section,
      action,
      step,
      coach_message:
        section === "core-value"
          ? "Draft a single core value that describes the lasting emotional outcome you deliver for customers. Keep it short and testable."
          : section === "swot"
          ? "Pick the top 3 issues and top 3 opportunities. Then choose ONE strategy (Revise / Expand / Disrupt) to focus for the next 90 days."
          : section === "root-cause"
          ? "Write the problem as an observable constraint. List symptoms, then ask 'why' five times to isolate root causes. Avoid solutions in the problem statement."
          : section === "time-audit"
          ? "Tag tasks as High/Medium/Low value. Reclaim hours by eliminating, delegating, automating, or batching low-value work."
          : "Keep going — focus on clarity and one next step.",
      suggested_next_questions: [
        "What will change in 90 days if you execute this perfectly?",
        "What is the one decision you are avoiding?",
        "What is the smallest experiment you can run this week?",
      ],
      inputs_echo: { current_answers, context },
    };

    return res.json({ success: true, analysis: response });
  }

  if (name === "strategyDiagnosis") {
    try {
      const { action = "start", treeId = "pickone-v2", state: incomingState, questionId, answerId } = req.body || {};
      const tree = getTree(treeId);

      if (action === "start") {
        const state = initState(treeId);
        const firstId = tree.startId;
        state.currentQuestionId = firstId;
        const q = getQuestion(tree, firstId);
        return res.json({ state, question: sanitizeQuestion(q), tree: { id: tree.id, name: tree.name } });
      }

      if (!incomingState) {
        return res.status(400).json({ error: "Missing state" });
      }

      // Defensive copy
      let state = { ...incomingState, answers: { ...(incomingState.answers || {}) }, scores: { ...(incomingState.scores || {}) }, history: [...(incomingState.history || [])] };

      if (action === "answer") {
        if (!questionId || !answerId) {
          return res.status(400).json({ error: "Missing questionId or answerId" });
        }
        const { nextState, nextQuestionId } = applyAnswer(tree, state, questionId, answerId);
        state = nextState;
        const nextId = chooseNextQuestionId(tree, state, nextQuestionId) || tree.finalizeId;
        state.currentQuestionId = nextId;

        if (nextId === tree.finalizeId) {
          const rec = recommend(state, tree);
          return res.json({ state, result: rec, done: true });
        }
        const q = getQuestion(tree, nextId);
        return res.json({ state, question: sanitizeQuestion(q), done: false });
      }

      if (action === "result") {
        const rec = recommend(state, tree);
        return res.json({ state, result: rec, done: true });
      }

      return res.status(400).json({ error: `Unknown action: ${action}` });
    } catch (e) {
      return res.status(500).json({ error: e?.message || "strategyDiagnosis failed" });
    }
  }

  function sanitizeQuestion(q) {
    // avoid returning server-only fields later; keep minimal now
    return {
      id: q.id,
      prompt: q.prompt,
      tag: q.tag || null,
      answers: (q.answers || []).map((a) => ({ id: a.id, label: a.label })),
    };
  }


  if (name === "semanticSearch") {
    // Simple keyword search across clips + videos
    await db.read();
    const q = String(req.body?.query || "").toLowerCase().trim();
    const limit = Number(req.body?.limit || 10);

    const clips = db.data.Clip || [];
    const videos = db.data.Video || [];

    const scored = [];

    function scoreText(text) {
      if (!q) return 0;
      const t = String(text || "").toLowerCase();
      let score = 0;
      for (const term of q.split(/\s+/).filter(Boolean)) {
        if (t.includes(term)) score += 1;
      }
      return score;
    }

    for (const c of clips) {
      const score = scoreText(`${c.title} ${c.description} ${c.transcript_excerpt}`);
      if (score > 0) scored.push({ type: "clip", score, item: c });
    }
    for (const v of videos) {
      const score = scoreText(`${v.title} ${v.transcript_text}`);
      if (score > 0) scored.push({ type: "video", score, item: v });
    }

    scored.sort((a, b) => b.score - a.score);
    return res.json({ success: true, results: scored.slice(0, limit) });
  }

  return res.status(404).json({ error: `Unknown function: ${name}` });
});

await initDb();
app.listen(PORT, () => {
  console.log(`Pick One server listening on http://localhost:${PORT}`);
});