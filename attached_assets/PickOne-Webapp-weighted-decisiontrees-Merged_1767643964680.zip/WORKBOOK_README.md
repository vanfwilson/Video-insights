# Pick One Workbook - Integration Guide

## Overview

This package integrates the Pick One Workbook into your existing Video-insights app. The workbook follows your exact architectural patterns:

- **React Query** for state management
- **Base44 SDK** for backend/database
- **Shadcn/Radix UI** components
- **React Router** for navigation
- **Tailwind CSS** for styling
- **Serverless functions** for AI features

---

## Quick Start

### Step 1: Copy Files

Copy these files to your project:

```bash
# Pages (copy to src/pages/)
WorkbookDashboard.jsx
WorkbookCoreValue.jsx
WorkbookSWOT.jsx
WorkbookRootCause.jsx
WorkbookTimeAudit.jsx

# Functions (copy to functions/)
workbookAICoach.ts

# Updated configs (replace existing)
pages.config.js  → src/pages.config.js
Layout.jsx       → src/Layout.jsx
```

### Step 2: Create Entities in Base44/Replit

Go to your Base44/Replit dashboard and create these entities:

#### WorkbookProgress
```
Fields:
- user_id (string, required)
- started_at (datetime)
- last_updated (datetime)
- completed_sections (array of strings)
- completion_percentage (number)
- status (string: in_progress, completed, archived)
```

#### CoreValue
```
Fields:
- user_id (string, required)
- workbook_id (string)
- how_you_were_made (text)
- business_given (text)
- desire_for_customers (text)
- problems_you_solve (text)
- principle_at_heart (text)
- feelings_generated (text)
- core_value_draft_1 (string)
- core_value_draft_2 (string)
- core_value_final (string)
- ai_suggestions (array of strings)
- alignment_scores (json)
- status (string)
- created_at (datetime)
- updated_at (datetime)
```

#### SWOTAnalysis
```
Fields:
- user_id (string, required)
- workbook_id (string)
- business_area (string, required)
- strengths (json)
- weaknesses (json)
- opportunities (json)
- threats (json)
- key_insight (text)
- key_metric (string)
- ai_patterns (array of strings)
- status (string)
- created_at (datetime)
- updated_at (datetime)
```

#### RootCauseChart
```
Fields:
- user_id (string, required)
- workbook_id (string)
- before_triggers (text)
- problem_description (text)
- after_results (text)
- five_whys (json)
- when_where_how (text)
- who_affected (text)
- when_not_issue (text)
- what_driving (text)
- conditions_worse (text)
- how_stop_forever (text)
- who_wins_loses (text)
- what_stopping_us (text)
- symptom (text)
- root_cause (text)
- priority_impact (text)
- problem_statement (text)
- affected_areas (array of strings)
- ai_root_cause_suggestion (text)
- status (string)
- created_at (datetime)
- updated_at (datetime)
```

#### TimeAudit
```
Fields:
- user_id (string, required)
- workbook_id (string)
- owner_rate (number)
- tasks (json)
- total_hours_logged (number)
- high_value_hours (number)
- medium_value_hours (number)
- low_value_hours (number)
- tasks_to_delegate (json)
- hours_to_reclaim (number)
- what_to_do_with_time (text)
- time_management_rating (number)
- biggest_time_wasters (array of strings)
- status (string)
- created_at (datetime)
- updated_at (datetime)
```

### Step 3: Deploy the Function

Deploy `workbookAICoach.ts` to your Base44/Replit functions.

### Step 4: Test

1. Run `npm run dev`
2. Navigate to `/WorkbookDashboard`
3. Test the Core Value section

---

## File Structure

```
workbook-integration/
├── src/
│   ├── pages/
│   │   ├── WorkbookDashboard.jsx    # Main entry point
│   │   ├── WorkbookCoreValue.jsx    # Section 1: Core Value
│   │   ├── WorkbookSWOT.jsx         # Section 2: SWOT Analysis
│   │   ├── WorkbookRootCause.jsx    # Section 3: Root Cause
│   │   └── WorkbookTimeAudit.jsx    # Section 4: Time Audit
│   ├── Layout.jsx                    # Updated with workbook nav
│   └── pages.config.js               # Updated with workbook routes
├── functions/
│   └── workbookAICoach.ts           # AI coaching function
├── entities/
│   └── workbookEntities.js          # Entity schemas (reference)
└── README.md                         # This file
```

---

## Architecture Alignment

### How It Matches Your Existing Patterns

| Pattern | Your App | Workbook Integration |
|---------|----------|---------------------|
| Data Fetching | `useQuery` + `base44.entities` | ✅ Same pattern |
| Mutations | `useMutation` + `queryClient.invalidateQueries` | ✅ Same pattern |
| Components | Shadcn `Card`, `Button`, `Input` | ✅ Same components |
| Styling | Tailwind + gradients | ✅ Same approach |
| Navigation | `pages.config.js` + `createPageUrl` | ✅ Same system |
| AI Functions | `base44.functions.invoke` + `InvokeLLM` | ✅ Same pattern |
| Auth | `base44.auth.me()` + role checks | ✅ Same pattern |

### Example: Data Fetching (Your Pattern)

```jsx
// From your SemanticSearch.jsx
const response = await base44.functions.invoke('semanticSearch', { 
    query: query.trim(),
    limit: 10
});

// Workbook uses identical pattern
const response = await base44.functions.invoke('workbookAICoach', {
    section: 'core-value',
    action: 'generate_suggestions',
    current_answers: formData
});
```

### Example: Entity CRUD (Your Pattern)

```jsx
// From your AdminDashboard.jsx
const { data: videos } = useQuery({
    queryKey: ['videos'],
    queryFn: () => base44.entities.Video.list('-created_date', 100)
});

// Workbook uses identical pattern
const { data: existingCoreValue } = useQuery({
    queryKey: ['coreValue', currentUser?.id],
    queryFn: async () => {
        const results = await base44.entities.CoreValue.filter({
            user_id: currentUser?.id
        });
        return results[0] || null;
    }
});
```

---

## AI Coach Features

The `workbookAICoach.ts` function provides:

### Core Value Section
- `generate_suggestions`: Creates 4 core value suggestions based on user answers
- `clarifying_question`: Returns relevant coaching questions

### SWOT Section
- `suggest_swot_items`: Suggests industry-specific SWOT items
- `detect_patterns`: Analyzes patterns across business areas

### Root Cause Section
- `guide_five_whys`: Guides through 5 Whys analysis
- `generate_problem_statement`: Creates problem statement from analysis

### Time Audit Section
- `analyze_tasks`: Analyzes task list for delegation opportunities

---

## Customization

### Change the Color Scheme

Each section has its own gradient. Edit in the page files:

```jsx
// WorkbookCoreValue.jsx - Blue theme
className="bg-gradient-to-br from-blue-50 via-white to-indigo-50"

// WorkbookSWOT.jsx - Green theme
className="bg-gradient-to-br from-green-50 via-white to-emerald-50"

// WorkbookRootCause.jsx - Purple theme
className="bg-gradient-to-br from-purple-50 via-white to-indigo-50"

// WorkbookTimeAudit.jsx - Orange theme
className="bg-gradient-to-br from-orange-50 via-white to-amber-50"
```

### Add More Business Areas to SWOT

Edit `BUSINESS_AREAS` array in `WorkbookSWOT.jsx`:

```jsx
const BUSINESS_AREAS = [
    { id: 'overall', label: 'Overall Business', icon: Building2 },
    // Add more here...
    { id: 'custom_area', label: 'My Custom Area', icon: Target }
];
```

### Customize AI Prompts

Edit `workbookAICoach.ts` to change how AI generates suggestions:

```typescript
const prompt = `You are a business coach helping a trades/construction business...`;
```

---

## Navigation Structure

```
/WorkbookDashboard     → Main workbook home with progress
/WorkbookCoreValue     → Section 1: Find Your Core Value
/WorkbookSWOT          → Section 2: SWOT Analysis
/WorkbookRootCause     → Section 3: Root Cause Chart
/WorkbookTimeAudit     → Section 4: Time Management
```

Users can navigate:
1. From Video Hub nav → Workbook dropdown → Any section
2. Sequentially through sections using Next/Previous buttons
3. Directly to any unlocked section from WorkbookDashboard

---

## Future Enhancements

### Suggested Next Steps

1. **Export to PDF**: Add ability to export completed workbook
2. **Team Collaboration**: Allow multiple team members to contribute
3. **Progress Notifications**: Email when sections are completed
4. **RAG Integration**: Connect AI coach to book content for deeper answers
5. **Mastermind Features**: Group coaching sessions based on workbook progress

### Database Migrations

If you need to add fields later, use Base44's entity update or Replit's database migration tools.

---

## Troubleshooting

### "Entity not found" Error

Make sure you created all entities in Base44/Replit dashboard with exact field names.

### AI Function Not Working

1. Check function is deployed
2. Verify `InvokeLLM` integration is enabled
3. Check function logs for errors

### Styling Issues

Make sure you have these Tailwind colors configured:
- blue, indigo (Core Value)
- green, emerald (SWOT)
- purple, indigo (Root Cause)
- orange, amber (Time Audit)

---

## Support

This integration follows your exact patterns from Video-insights. If you have questions about the architecture, reference your existing pages like `SemanticSearch.jsx` and `AdminDashboard.jsx` which use identical patterns.
